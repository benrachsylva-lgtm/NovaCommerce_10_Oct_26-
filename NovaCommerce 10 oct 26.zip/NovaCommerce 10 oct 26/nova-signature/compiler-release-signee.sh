#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# NOVA Commerce — compilation d'un APK release SIGNÉ avec la clé de l'éditeur
# ---------------------------------------------------------------------------
# Utilisation :
#   bash compiler-release-signee.sh
# Le script demande le mot de passe de la clé (voir LISEZ-MOI-SIGNATURE.md),
# compile la variante release, puis vérifie que l'APK est bien signé avec le
# certificat attendu — et que la conformité « resources.arsc » est respectée.
set -euo pipefail

ICI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RACINE="$(cd "$ICI/../Nova-Commerce" && pwd)"
KEYSTORE="$ICI/nova-commerce-release.p12"
ALIAS=nova-commerce
# Empreinte SHA-256 du certificat de l'éditeur (information publique) : sert à
# refuser tout APK signé avec une autre clé (clé de débogage, autre poste…).
EMPREINTE_ATTENDUE="35:6F:FD:1C:2A:4F:A8:CE:D4:D2:4B:CC:D5:A0:96:72:62:28:AA:55:79:B8:9E:A5:8C:A3:7C:C3:23:6A:9E:37"

# Chaîne d'outils : surchargez ces variables si votre poste diffère.
: "${JAVA_HOME:=/var/tmp/nova-build/jdk17}"
: "${ANDROID_HOME:=/var/tmp/nova-build/android-sdk}"
: "${GRADLE_USER_HOME:=/var/tmp/nova-build/gradle-home}"
export JAVA_HOME ANDROID_HOME GRADLE_USER_HOME
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$JAVA_HOME/bin:$PATH"

if [ ! -f "$KEYSTORE" ]; then
  echo "Clé introuvable : $KEYSTORE" >&2
  exit 1
fi

read -r -s -p "Mot de passe de la clé de signature : " MDP
echo
if [ -z "$MDP" ]; then
  echo "Mot de passe vide : abandon." >&2
  exit 1
fi

export NOVA_BUILD_CHANNEL=production
export NOVA_ANDROID_KEYSTORE_PATH="$KEYSTORE"
export NOVA_ANDROID_KEYSTORE_PASSWORD="$MDP"
export NOVA_ANDROID_KEY_ALIAS="$ALIAS"
export NOVA_ANDROID_KEY_PASSWORD="$MDP"

cd "$RACINE"
[ -x android/gradlew ] || chmod +x android/gradlew
npm run mobile:apk:release

echo
echo "=== Vérification de la signature et de la conformité ==="
node scripts/verify-apk.mjs NOVA-Commerce-release.apk --cert-sha256 "$EMPREINTE_ATTENDUE"

echo
echo "APK signé prêt : $RACINE/NOVA-Commerce-release.apk"
echo "Pensez à sauvegarder la clé et ce dossier (voir LISEZ-MOI-SIGNATURE.md)."

# NOVA Commerce

NOVA Commerce est une application de gestion commerciale et de stock en français, livrée en trois formes compatibles :

- PWA installable dans un navigateur Windows ou Android ;
- APK Android Capacitor installable ;
- application Desktop Windows Electron avec base SQLite relationnelle et setup installable.

La devise par défaut est le **FCFA**. Les écrans, libellés, documents, exports et messages sont en français.

## Correctifs 26/09/2026 — écritures refusées et exports Android

Deux défauts signalés en exploitation ont été corrigés et couverts par des tests de
non-régression (`npm run test:write`, plus le harnais Chromium `test-harness/e2e.cjs`).

**1. « La session ou la base locale ne permet pas cette écriture » lors de la validation
des bons de commande.** Ce message était unique pour toutes les causes possibles.
Il est désormais qualifié :

| Cause réelle | Comportement corrigé |
|---|---|
| Session Desktop expirée (8 h) | fenêtre **Session expirée** : saisie conservée puis **réenregistrée automatiquement** après reconnexion ; la session est en outre **renouvelée à l'usage** (session glissante) et surveillée toutes les 5 minutes |
| Essai terminé / licence inactive | message « Mode lecture seule » avec renvoi vers Licence → Activation |
| Droits insuffisants | message indiquant le **droit requis** (ex. `orders.manage`) |
| Donnée validée modifiée / supprimée | message « Opération refusée » expliquant la correction à faire (avoir, mouvement inverse) |
| Quota du stockage saturé | message « Stockage local saturé » avec l'occupation en % et la marche à suivre |
| Horloge système incohérente | message « Blocage de sécurité » |

Le journal d'activité est désormais borné à 3 000 entrées et le module
**Journal d'activité** affiche l'occupation du stockage local ainsi qu'un bouton
**Purger le journal d'activité** pour libérer de la place avant saturation.

**2. Exports et PDF inopérants dans l'APK.** Android WebView n'exécute ni `a[download]`
sur une URL `blob:` ni `window.print()`. Un plugin natif Capacitor sans dépendance npm
(`NovaExportPlugin`) écrit désormais les exports dans **Téléchargements / NOVA Commerce**
(ou les met à disposition via le partage) et imprime via **PrintManager**, ce qui rend
la fonction « Enregistrer en PDF » opérationnelle. Voir `GUIDE-COMPILATION-APK.md` § 2.

Les exports « Excel » sont des fichiers **CSV** (séparateur `;`, BOM UTF-8) ouverts
directement par Excel.

## Fonctionnalités métier

- Tableau de bord : chiffre d’affaires, marge, dépenses, résultat, stock, créances et alertes. Chaque bénéfice est décliné **avec créances** (toutes les ventes validées) et **encaissé / hors créances** (ventes au comptant + ventes à crédit au prorata des règlements, imputés au report initial puis aux plus anciennes dettes de chaque client). Il suit aussi les livraisons (cartes jour et mois, dernières affectations) et le recouvrement (taux d’encaissement, règlements reçus, derniers règlements).
- Vente rapide avec recherche, panier multi-produits, vente comptant, Mobile Money, carte et vente à crédit.
- Vente à crédit obligatoirement liée à un client enregistré ; contrôle de la limite de crédit avant validation.
- Journal des créances clients : solde initial, ventes à crédit validées, règlements partiels ou successifs, référence externe, date, mode, note, utilisateur et solde courant.
- Fiche client avec historique débit/crédit et bouton d’enregistrement d’un règlement.
- Catalogue : produits, catégories, fournisseurs et magasins.
- Livreurs : enregistrement des livreurs (nom, prénoms, contacts, adresse, tarif de base, CIN, informations) et affectation d’un livreur aux ventes réalisées depuis l’Historique des ventes via le bouton « Livraison ».
- Liaison fournisseurs-produits dans **Fournisseurs** : choisir un fournisseur, sélectionner plusieurs produits existants, valider la sélection et conserver une relation plusieurs-à-plusieurs ; un produit peut donc avoir plusieurs fournisseurs sans supprimer son fournisseur principal historique.
- Stock séparé par magasin avec balances `produit × magasin`.
- Module Inventaire : comptage réel, calcul des écarts, génération d’un rapport daté et historique des rapports déjà réalisés.
- Entrées et sorties avec états « En cours » / « Validé » : une opération en cours ne touche pas le stock et une opération validée ne l’applique qu’une fois.
- Réception des commandes fournisseurs : le module Entrées de stock affiche les commandes du dernier mois ; le bouton « Réception » transforme une commande multi-lignes en entrées validées et augmente le stock de chaque produit une seule fois.
- Commandes fournisseurs et devis multi-lignes avec calcul des sous-totaux, remises, TVA et totaux.
- Commande Express : analyse des ventes et du stock, propositions de réassort par fournisseur, validation puis génération des bons de commande.
- Rapports d’achats, de ventes, de dépenses, comptabilité, inventaire et journal d’activité.
- Utilisateurs et profils RBAC : les permissions sont contrôlées par l’interface et par Electron avant les écritures. La matrice d’accès détaille tous les modules du menu (ouverture + gestion) pour chaque profil.
- Recherche, filtres de période, filtres de statut/catégorie et pagination réelle des tableaux.
- Rapports PDF : chaque rapport (ventes, achats, stocks, dépenses, créances, bénéfices) possède un bouton PDF générant indicateurs clés, graphiques et tableaux sur le mois passé, le mois en cours, l'année en cours et l'année passée. Le rapport fournisseurs liste, pour chaque fournisseur, ses produits (référence, catégorie, prix d’achat/vente, stock, statut), avec une section pour les produits sans fournisseur ; il s’imprime depuis la vue Fournisseurs (▣ Rapport PDF) ou depuis Rapports.
- Journal d'activité : sauvegarde complète de la base (JSON horodaté), restauration contrôlée, et exports CSV des tables importantes (ventes, produits, stocks par magasin, clients, règlements, fournisseurs, livreurs, entrées, sorties, commandes, devis, dépenses, journal).
- Exports CSV et impressions respectant la période active lorsque le module possède un filtre de date.
- Impression complète des commandes et devis : entreprise, partenaire, date, numéro, statut, lignes, quantités, prix, totaux et zones de signature.
- Ticket de caisse avec secours par impression système, plus Web Serial, WebUSB et Bluetooth selon le navigateur et l’imprimante.
- Module Licence : essai de trois mois, lecture seule après expiration et activation permanente par code valide.
- Module « Guide utilisateur » : parcours de démarrage, règles métier, raccourcis et mode d’emploi de tous les modules.
- Écran de chargement NOVA Commerce : visuel fourni dans `nova-loading.png`, affiché pendant au moins quatre secondes avant la configuration initiale ou la connexion sur la PWA, Android et Electron.
- Icône NOVA Commerce : logo officiel fourni dans `user-icon.png`, visible à la connexion et utilisé par la PWA, Android et les packages Desktop.
- Module « Nous contacter » : IAFAD Consulting, Ouagadougou, Burkina Faso, `+226 76 83 04 82`. L’« Espace concepteur », déverrouillé par code d’accès, pilote la disponibilité des modules du menu via une matrice exhaustive.

## Premier démarrage et choix de la base

Lors de la première ouverture sur un appareil, NOVA affiche un assistant avant l’écran de connexion. Il permet de choisir entre :

- **Charger la démonstration** : les produits, stocks, ventes, clients, fournisseurs et autres exemples sont préchargés ;
- **Charger une base neuve** : aucune donnée métier n’est chargée, mais le compte Administrateur protégé reste disponible pour se connecter.

Le choix est enregistré localement dans la PWA, Android ou SQLite Electron et l’assistant ne réapparaît pas lors des ouvertures suivantes. Une base neuve peut ensuite être alimentée depuis les modules métier. Les données de démonstration peuvent être restaurées ultérieurement depuis **Licence → Activation** après activation valide.

## Livrables présents

```text
NOVA-Commerce-Setup.exe       Setup Windows Electron de test
NOVA-Commerce-debug.apk       APK Android de test, signé par la clé debug Android
NOVA-Commerce-release-unsigned.apk
                              APK release Android de test non signé
NOVA-Commerce-Rayira-special.apk
                              Variante de test avec écran Rayira
NOVA-Commerce-NOVA-loading-special.apk
                              Variante de test avec écran NOVA Commerce
www/                          Copie PWA synchronisée, incluant user-icon.png
android/app/src/main/assets/public/
                              Assets Android synchronisés, incluant user-icon.png
```

Empreintes SHA-256 des artefacts de test actuels :

```text
NOVA-Commerce-Setup.exe             99af339630b7d737d07f75d29c54a4635d56c13fca92cb5ff8d5ce799195453d
NOVA-Commerce-debug.apk             6012f4ac903f044d13d080b9132be3e55636dd1fb017550e87a3250868593e05
NOVA-Commerce-release-unsigned.apk  2865e67c237292bb8681b8fb3ca49d80628fe24a59f7b056ec1317486290cfed
NOVA-Commerce-Rayira-special.apk     839ca0d81cad0c034c5d902cb1481ceabbe25da60f31490b1b6c457a844be7ef
NOVA-Commerce-NOVA-loading-special.apk cf1ebffbc2dd134845ceba5c1478288cdacc7f0b6a05de463cfc17c0681908f2
```

Les binaires Android sont des **builds de test** : l’APK debug est signé par une clé debug et l’APK release est volontairement non signé. Ils ne doivent pas être présentés comme des livrables commerciaux signés tant qu’ils n’ont pas été reconstruits avec les certificats officiels décrits plus bas.

## Guide complet en format Word

Le guide opérationnel, administrateur, sécurité, licence, impression, sauvegarde et déploiement est disponible dans :

```text
Guide-complet-NOVA-Commerce.docx
```

Il couvre la PWA, l’APK Android, le Desktop Electron/SQLite, tous les modules métier, les règles « En cours » / « Validée », les créances et règlements, les avoirs, les transferts, les profils, les limites locales et les procédures de production.

## Desktop Windows, Electron et SQLite

L’application Desktop utilise Electron avec `contextIsolation`, `nodeIntegration: false`, preload isolé et session d’authentification gérée par le processus principal. La base est créée dans le dossier de données utilisateur Electron :

```text
C:\Users\<utilisateur>\AppData\Roaming\NOVA Commerce\nova-commerce.sqlite
```

Le processus principal conserve les données métier dans SQLite et ne traite plus l’ancien JSON comme source principale. Le schéma relationnel version 7 comprend notamment :

- `users`, `roles` et permissions persistées ;
- `products`, `product_stock` et stock par magasin ;
- `suppliers`, `supplier_products` avec clé composite fournisseur-produit pour les associations plusieurs-à-plusieurs ;
- `inventory` pour les comptages courants et `inventory_reports`, `inventory_report_lines` pour les rapports d’inventaire datés et archivés ;
- `sales` (avec le prix appliqué : vente, gros ou promotionnel), `sale_lines` ;
- `credit_notes`, `credit_note_lines` pour les avoirs et annulations liés à une vente ;
- `clients` avec `opening_receivable` et `receivable` calculé ;
- `customer_payments` pour les règlements clients ;
- `stock_movements`, `stock_movement_lines` avec références de mouvements inverses ;
- `stock_transfers`, `stock_transfer_lines` pour les transferts inter-magasins équilibrés ;
- `orders` (avec indicateur Commande Express), `order_lines`, `quotes`, `quote_lines` ;
- `expenses`, `inventory` et `activities` ;
- `app_state_meta` pour les paramètres, la licence et le point de contrôle d’intégrité de l’horloge.

Une transaction SQLite remplace l’état relationnel lors d’une écriture autorisée. Les sauvegardes de la base sont accessibles dans le menu **Fichier** de l’application Desktop.

Le journal `activities` est append-only autant que possible : le processus principal ne supprime pas les événements lors d’une synchronisation d’état et utilise une insertion idempotente. Aucun bouton utilisateur de purge du journal n’est fourni. Une protection absolue contre un propriétaire de machine qui modifie directement son fichier SQLite n’est pas possible avec une application locale ; cette limite est explicitement documentée dans `ANALYSE-CRITIQUE.md`.

## Authentification et profils

L’accès à la fenêtre principale nécessite un nom d’utilisateur et un mot de passe. Les mots de passe ne sont jamais stockés en clair : les nouveaux mots de passe utilisent PBKDF2-SHA-256 avec sel individuel et 120 000 itérations.

Compte Administrateur protégé :

```text
Nom d’utilisateur : %@PBGgS86D7@N
Profil            : Administrateur
```

Le mot de passe de ce compte est communiqué par le responsable du déploiement et n’est jamais écrit dans le dépôt, le README ou la base en clair. L’application embarque uniquement son hachage PBKDF2-SHA-256. Les autres comptes de démonstration (`mariam` et `issouf`) sont provisionnés avec des hachages et peuvent être remplacés depuis **Administration → Utilisateurs**.

Dans Electron, le processus principal vérifie le mot de passe depuis SQLite, crée une session temporaire et refuse les écritures sans session ou sans permission. Le nom affiché dans l’accueil du tableau de bord provient dynamiquement du champ **Nom et prénom / identité** de l’utilisateur connecté. Les profils de démonstration comprennent notamment Administrateur, Gérant, Vendeur, Magasinier et Comptable. Les droits `credit.view` et `credit.record` sont appliqués aux profils concernés.

## Guide utilisateur

Le module **Guide utilisateur** est accessible depuis le menu **Assistance** et par la carte d’aide du sidebar. Il explique :

- le démarrage recommandé : sécurité, paramètres, catalogue, stock initial puis première vente ;
- les règles « En cours » / « Validée », les contrôles de stock et les corrections historisées ;
- les raccourcis `F2`, `⌘ K`, double-clic et `Échap` ;
- l’utilisation des ventes, clients, produits, catégories, magasins, fournisseurs, entrées, sorties, transferts, commandes, inventaire, devis, avoirs, rapports, dépenses, comptabilité, utilisateurs, profils, journal, licence et paramètres ;
- des liens directs pour ouvrir chaque module depuis sa fiche explicative.

Le guide est consultable par tous les comptes, y compris en lecture seule.

## Lier des fournisseurs aux produits

Dans **Fournisseurs**, la section **Produits fournis par fournisseur** permet de :

1. choisir un fournisseur actif ;
2. rechercher et cocher plusieurs produits déjà présents dans la base ;
3. cliquer sur **Valider la sélection** pour enregistrer les relations ;
4. décocher les produits puis valider pour retirer leurs liens avec ce fournisseur.

La sélection remplace uniquement les liens du fournisseur choisi. Les liens des autres fournisseurs sont conservés, ce qui permet d’associer un même produit à plusieurs fournisseurs. Le champ **Fournisseur principal** de la fiche produit reste compatible et n’est pas écrasé par cette section. La fonctionnalité est disponible dans la PWA, Android et Electron ; Electron la persiste dans la table SQLite `supplier_products`.

## Rapports d’inventaire

Dans **Stocks → Inventaire**, saisir les comptages réels puis cliquer sur **Générer le rapport**. Le logiciel demande la date de l’inventaire et un libellé facultatif, calcule les stocks théoriques, les quantités réelles et les écarts, puis enregistre une photographie complète du comptage. Le rapport peut ensuite être consulté ou imprimé depuis **Rapports d’inventaire enregistrés**.

Chaque rapport conserve sa référence, sa date, son utilisateur, ses lignes et ses écarts. Les rapports précédents ne sont pas écrasés lorsqu’un nouvel inventaire est réalisé. La PWA et Android les conservent dans l’état local ; Electron les persiste dans `inventory_reports` et `inventory_report_lines`.

## Créances et règlements

L’encours d’un client n’est pas saisi directement dans l’interface. Il est reconstruit ainsi :

```text
encours = solde initial
        + ventes à crédit dont le statut est « Validée »
        - règlements dont le statut est « Validé »
```

Un règlement contient :

- un numéro interne `REG-...` ;
- une date ;
- un montant partiel ou total ;
- un mode : Cash, Mobile Money, Carte ou Chèque ;
- une référence externe facultative ;
- une note facultative ;
- l’utilisateur et le statut de validation.

Les règlements sont persistés dans SQLite Desktop et dans l’état local PWA/Android. Ils sont exportables depuis la fiche Clients via **Règlements**.

## Avoirs, annulations et corrections stock

Une vente validée n’est jamais modifiée ni supprimée. Depuis le détail d’une vente, **Créer un avoir / annuler** ouvre un parcours guidé avec :

- avoir partiel ou annulation complète ;
- sélection des lignes et quantités encore disponibles ;
- motif obligatoire ;
- choix du retour physique des articles en stock ;
- statut **En cours** ou **Validée**.

La correction est enregistrée dans `credit_notes` et `credit_note_lines`, liée à la vente d’origine, avec son utilisateur, ses lignes, son montant et son motif. Une correction « En cours » ne modifie ni le stock ni les calculs financiers. Une correction validée diminue le chiffre d’affaires et l’encours si la vente était à crédit. Le stock n’est réintégré qu’une seule fois si le retour est demandé. Les entrées et sorties validées disposent également de l’action **Créer le mouvement inverse** : elle préremplit une nouvelle opération « En cours » liée à la référence originale, sans modifier l’opération initiale.

## Transferts inter-magasins

Le module **Stocks → Transferts inter-magasins** utilise une opération dédiée avec plusieurs lignes, magasin source, magasin destination, motif et statut. Une opération « En cours » ne touche aucun stock. À la validation, les quantités sont retirées du magasin source et ajoutées au magasin destination dans la même opération, une seule fois. Les deux magasins et les lignes sont persistés dans `stock_transfers` et `stock_transfer_lines` et restent historisés.

## Filtres, pagination et impressions

Le bouton **Période** ouvre un filtre global avec une date de début et une date de fin. La période active est utilisée par les listes concernées, les indicateurs de rapports, les exports CSV et les impressions de rapports. Les filtres de recherche et de statut sont combinés avec une pagination de dix lignes par page ; les boutons de page modifient réellement les lignes visibles.

Les impressions **Bon de commande** et **Devis** produisent un document système complet et non plus un simple message. Les informations de l’entreprise proviennent de **Paramètres** et les informations du fournisseur/client, des lignes et des totaux proviennent du document enregistré.

## Licence locale

Le logiciel démarre avec un essai de **trois mois**. Après expiration, les données restent consultables, imprimables et exportables, mais les créations, modifications et validations passent en lecture seule.

Pour activer le fonctionnement permanent, chaque installation reçoit une **clé personnelle d’appareil**, liée à deux informations obligatoires :

1. le **nom de la boutique / entreprise** (saisi dans **Paramètres**) ;
2. le **code UUID de l’appareil** (identifiant unique affiché dans **Nous contacter**).

Le parcours client est le suivant : ouvrir **Nous contacter**, vérifier le nom de boutique et le code UUID affichés, puis cliquer **Demander ma licence** pour envoyer ces informations par SMS à IAFAD Consulting (**+226 76 83 04 82**). La clé reçue en retour se colle dans **Administration → Licence** ; elle est vérifiée **hors-ligne** et active le fonctionnement illimité sur cet appareil uniquement.

Après activation correcte, la section **Activation** affiche le nom de boutique et l’UUID liés à la clé, ainsi que — uniquement pour l’administrateur — les actions **Réinitialiser la démo** et **Mettre à neuf la base**. Cette dernière supprime les données métier locales et conserve le compte Administrateur protégé ainsi qu’un événement d’audit de l’opération. **Renommer la boutique ou changer d’appareil invalide la clé** : une nouvelle clé doit alors être demandée.

Techniquement, la clé est une signature **ECDSA P-256** du couple normalisé `(nom, UUID)`, encodée en Crockford Base32 avec le préfixe `NOVA1`. La clé privée de signature reste dans l’outil générateur (`Nova-Licence-Generator/`, jamais diffusée) ; le logiciel embarque uniquement la clé publique de vérification. Sur PC (Electron), l’UUID est celui de la machine (registre Windows, `/etc/machine-id`, `IOPlatformUUID`) ; sur Android et en PWA, c’est un UUID généré par l’application et conservé localement. Dans Desktop, le renderer vérifie la signature puis demande en plus une contre-vérification au processus principal Electron, qui remet un ticket d’activation temporaire avant d’autoriser l’écriture de la licence.

Cette licence reste un mécanisme local : le paquet ou les fichiers locaux peuvent être attaqués par le propriétaire de l’appareil. Elle ne gère ni révocation à distance ni renouvellement. Pour une licence commerciale sensible, il faudrait déplacer l’émission et la vérification vers un service distant signé, avec activation liée à un compte/appareil, révocation et renouvellement. Voir la section des limites dans `ANALYSE-CRITIQUE.md`.

## Contrôle d’intégrité de la date système

À chaque ouverture, lecture d’état, authentification et écriture, NOVA mémorise dans le Desktop SQLite et dans le fichier séparé `nova-clock-integrity.json` la date la plus avancée déjà observée. Un recul de l’horloge de plus de **cinq minutes** par rapport à cette valeur est considéré comme suspect. Le contrôle détecte également un retour en arrière après une avance artificielle de la date.

Lorsqu’un recul est détecté :

- un événement est ajouté au journal d’audit ;
- le verrou est conservé, même si l’heure est ensuite corrigée ;
- les opérations commerciales, validations, paramétrages et activations sont désactivés ;
- tous les comptes existants restent autorisés à se connecter pour consulter, imprimer et exporter les données, mais l’application est en **lecture seule pour tous**.

Limite connue : sur PWA/Android, la garde anti-recul est conservée dans le stockage web local (`nova-clock-integrity-v1`) ; vider les données du navigateur la réinitialise et fait repartir le contrôle de zéro. C’est acceptable pour une application locale-first (l’attaquant possède déjà l’appareil et ses données). Côté Desktop, la garde est persistée dans SQLite et dans `nova-clock-integrity.json`, et survit au vidage du stockage web.

La PWA et Android utilisent le même contrôle local. Comme toute application locale, elles ne peuvent pas empêcher un propriétaire de supprimer ou modifier toutes les données locales. Pour une garantie indépendante, il faut un serveur de temps/licence signé et un contrôle distant. La procédure de remise en service doit donc être réalisée par l’assistance ou par une restauration contrôlée d’une base et d’un environnement fiables.

## Construire la PWA et Android

Les prérequis et la procédure complète de compilation Android sont documentés dans [`GUIDE-COMPILATION-APK.md`](GUIDE-COMPILATION-APK.md). Le résumé ci-dessous présente uniquement les commandes principales.

Après toute modification de `index.html`, `styles.css`, `app.js`, `manifest.json` ou `service-worker.js`, synchroniser les deux copies mobiles :

```bash
npm run mobile:sync
npx cap sync android
```

La version Android de test :

```bash
npm run mobile:apk:debug
```

Règle de livraison : les APK sont **toujours** construits via `npm run mobile:apk:debug` ou `npm run mobile:apk:release` (resynchronisation `www/` + `cap sync` incluse). Ne jamais commiter ni livrer des assets `android/app/src/main/assets/public/` périmés : le test `test:prod` contrôle que les 8 fichiers web sont identiques à la racine, dans `www/` et dans les assets Android.

Elle utilise la clé debug Android de l’environnement et produit `NOVA-Commerce-debug.apk`. Une release sans configuration de certificat est volontairement nommée `NOVA-Commerce-release-unsigned.apk`.

## Signature Android de production

Les mots de passe, keystore et certificats ne doivent jamais être commités. Préparer un keystore commercial hors du dépôt, puis fournir les variables uniquement au job de build sécurisé :

```text
NOVA_BUILD_CHANNEL=production
NOVA_ANDROID_KEYSTORE_PATH=C:\secrets\nova-commerce-release.jks
NOVA_ANDROID_KEYSTORE_PASSWORD=<mot de passe fourni par le coffre de secrets>
NOVA_ANDROID_KEY_ALIAS=nova-commerce
NOVA_ANDROID_KEY_PASSWORD=<mot de passe fourni par le coffre de secrets>
```

Puis exécuter :

```bash
npm run mobile:sync:capacitor
npm run mobile:apk:release
```

Le script échoue si `NOVA_BUILD_CHANNEL=production` est demandé sans les quatre paramètres de signature. Le résultat commercial est `NOVA-Commerce-release.apk`. Vérifier ensuite la signature avec `apksigner verify --verbose` et conserver l’empreinte SHA-256 du certificat dans les documents de livraison. L’APK debug et la release unsigned sont des artefacts de test, pas des builds commerciaux.

## Construire le Desktop Windows et le signer

Build local de test :

```bash
npm run desktop:setup
```

Sans variables de signature, le script affiche un avertissement et produit un setup de test/non signé pour la production. Pour une release commerciale, fournir le certificat éditeur Windows au job CI ou à une machine de build protégée :

```text
NOVA_BUILD_CHANNEL=production
CSC_LINK=C:\secrets\nova-commerce-code-signing.pfx
CSC_KEY_PASSWORD=<mot de passe fourni par le coffre de secrets>
```

`WIN_CSC_LINK` peut être utilisé à la place de `CSC_LINK`. Le mot de passe n’est jamais placé dans `package.json`, le dépôt, le fichier `.env` versionné ou l’application. Construire ensuite :

```bash
npm run desktop:setup
```

Le script refuse le canal `production` sans certificat officiel. Electron Builder utilise `CSC_LINK`/`WIN_CSC_LINK` pour signer le setup et les exécutables. Après construction, vérifier le certificat et la chaîne avec les outils Windows (`signtool verify /pa /v NOVA-Commerce-Setup.exe`) et conserver l’empreinte du certificat dans le procès-verbal de release.

La distinction est donc la suivante :

| Artefact | Signature | Usage |
|---|---|---|
| `NOVA-Commerce-debug.apk` | clé debug Android | test et installation interne |
| `NOVA-Commerce-release-unsigned.apk` | aucune | test de packaging uniquement |
| `NOVA-Commerce-release.apk` | keystore officiel fourni au build | publication commerciale Android |
| `NOVA-Commerce-Setup.exe` sans `CSC_LINK` | non signé / test | validation interne uniquement |
| `NOVA-Commerce-Setup.exe` avec `CSC_LINK` | certificat officiel Windows | distribution commerciale |

### Compiler le setup depuis Linux (sans Wine) et le vérifier

`electron-builder` produit l'installeur NSIS avec son propre `makensis` Linux, mais
réclame Wine pour la seule étape d'extraction de l'uninstaller. `scripts/build-desktop.mjs`
applique donc automatiquement `scripts/patch-nsis-linux.mjs` sur les plateformes non
Windows : l'uninstaller est extrait par le lecteur NSIS en JavaScript intégré à
`electron-builder`, et **Wine n'est plus nécessaire** (utile pour un runner Linux ou
un conteneur de compilation). Sous Windows, rien ne change.

```bash
node scripts/patch-nsis-linux.mjs   # appliqué automatiquement par desktop:setup hors Windows
NOVA_DESKTOP_OUTPUT_DIR=/tmp/nova-desktop npm run desktop:setup   # intermédiaires hors du dépôt
```

`NOVA_DESKTOP_OUTPUT_DIR` est facultatif : il redirige le dossier d'assemblage
(`desktop-dist/` par défaut) pour ne pas alourdir le dépôt ou le poste de build.
L'artefact final est toujours copié à la racine sous `NOVA-Commerce-Setup.exe`.

Vérification du setup produit (sans Windows) :

```bash
file NOVA-Commerce-Setup.exe                 # → Nullsoft Installer self-extracting archive
7za l NOVA-Commerce-Setup.exe                # → $PLUGINSDIR/app-64.7z + $R0/Uninstall NOVA Commerce.exe
sha256sum NOVA-Commerce-Setup.exe            # empreinte à consigner dans la livraison
```

À savoir : `desktop:setup` remplace le binaire natif `better-sqlite3` par la version
**Windows** ; sur une machine Linux, restaurez le binaire local avant de relancer les
suites Node (`npm rebuild better-sqlite3`, ou `prebuild-install` pour `node`/linux).

Un setup non signé déclenche l'avertissement SmartScreen « Windows a protégé votre
PC » : c'est attendu sans certificat éditeur (§ précédent), et disparaît une fois le
setup signé avec `CSC_LINK`.

## Lancer l’application web

Le projet web ne dépend pas d’un CDN pour l’interface :

```bash
python3 -m http.server 4173
```

Puis ouvrir `http://localhost:4173`. Sous Windows, `start-windows.bat` lance le serveur si Python 3 est installé. Edge et Chrome permettent ensuite l’installation PWA.

## Imprimante ticket

Dans **Paramètres → Imprimante ticket** :

- **Impression système** : solution de secours compatible Windows et Android ;
- **Web Serial** : imprimantes thermiques exposées comme port COM ;
- **WebUSB** : périphériques ESC/POS compatibles ;
- **Bluetooth** : imprimantes exposant un service GATT d’écriture.

Chrome/Edge et une page HTTPS ou localhost sont généralement nécessaires pour l’accès matériel. Le ticket système reste disponible si le modèle ou le navigateur ne permet pas la connexion directe.

## Réinitialiser la démo et sauvegarder

**Paramètres → Réinitialiser la démo** remet les données métier d’exemple à zéro. Le journal Desktop SQLite n’est pas purgé par une synchronisation normale ; fermez l’application avant toute copie/restauration manuelle de `nova-commerce.sqlite`.

## Limites connues et passage en production

PWA et Android sont local-first : les données sont stockées sur l’appareil et il n’existe pas encore de serveur de synchronisation multi-utilisateur. Desktop protège les écritures par session, RBAC, SQLite et transaction, mais le propriétaire de la machine peut toujours attaquer une application locale ou son fichier.

Pour une exploitation commerciale sensible, prévoir en complément : API HTTPS, authentification serveur, autorisation serveur, sauvegardes chiffrées, synchronisation avec résolution de conflits, journal d’audit distant/chaîné, gestion complète des retours fournisseurs, clôture de caisse et supervision des clés de signature.

Un rapport détaillé des risques, des correctifs appliqués et des limites restantes est disponible dans `ANALYSE-CRITIQUE.md`.

## Compilation du Setup Windows sur un PC Windows

1. Installez **Node.js LTS** depuis https://nodejs.org/ (aucun autre prérequis :
   pas de wine ni de SDK — tout est téléchargé automatiquement).
2. Double-cliquez **`Compiler-Setup-Windows.bat`** : il installe les dépendances
   (`npm install`) si besoin, puis lance `npm run desktop:setup`.
3. Récupérez **`NOVA-Commerce-Setup.exe`** à la racine du projet.

Le Setup obtenu est non signé (signature de code désactivée :
`win.signExecutable: false` dans `package.json`, aucune variable CSC requise).
Windows affichera une alerte SmartScreen à l'installation, c'est normal.
Pour signer plus tard avec un certificat : retirez cette option, définissez
`CSC_LINK` + `CSC_KEY_PASSWORD`, et relancez la compilation.

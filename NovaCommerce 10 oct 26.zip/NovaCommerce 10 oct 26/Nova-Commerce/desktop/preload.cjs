const { contextBridge, ipcRenderer } = require('electron');

let sessionToken = '';

// Les refus de la base locale remontent leur motif : l'interface peut ainsi
// afficher « session expirée », « droits insuffisants », « horloge »… au lieu
// d'un message d'erreur générique et trompeur.
const WRITE_REASONS = {
  session: { code: 'NOVA_SESSION_EXPIRED', message: 'Session expirée : reconnectez-vous pour enregistrer.' },
  droits: { code: 'NOVA_WRITE_DENIED', message: 'Écriture refusée : ce profil ne dispose pas des droits nécessaires.' },
  horloge: { code: 'NOVA_CLOCK_TAMPER', message: 'Écriture refusée : horloge système incohérente.' },
  'licence-lecture-seule': { code: 'NOVA_LICENSE_READONLY', message: 'Lecture seule : la période d’essai est terminée sur cet appareil.' },
  'licence-requise': { code: 'NOVA_LICENSE_READONLY', message: 'Lecture seule : activez la licence pour enregistrer.' },
  'licence-desactivee': { code: 'NOVA_LICENSE_READONLY', message: 'Lecture seule : la licence de cet appareil n’est plus active.' },
  'licence-modifiee': { code: 'NOVA_LICENSE_READONLY', message: 'Lecture seule : les informations de licence ont été modifiées hors de l’application.' },
  'licence-essai-modifie': { code: 'NOVA_LICENSE_READONLY', message: 'Lecture seule : la date de début d’essai a été modifiée.' },
  'licence-activation-invalide': { code: 'NOVA_LICENSE_READONLY', message: 'Activation refusée : demandez un nouveau code d’activation.' },
  'integrite-vente': { code: 'NOVA_INTEGRITY', message: 'Vente déjà validée : créez un avoir au lieu de la modifier.' },
  'integrite-avoir': { code: 'NOVA_INTEGRITY', message: 'Avoir déjà validé : créez une opération de correction.' },
  'integrite-transfert': { code: 'NOVA_INTEGRITY', message: 'Transfert déjà validé : créez un transfert inverse.' },
  'integrite-mouvement-stock': { code: 'NOVA_INTEGRITY', message: 'Mouvement de stock déjà validé : créez un mouvement inverse.' },
  'encours-client-modifie': { code: 'NOVA_INTEGRITY', message: 'L’encours d’un client ne peut être modifié que par une vente, un avoir ou un règlement.' },
  'base-absente': { code: 'NOVA_DB_MISSING', message: 'Base locale introuvable : redémarrez NOVA Commerce.' },
  volume: { code: 'NOVA_WRITE_DENIED', message: 'Écriture refusée : elle supprimerait une grande partie des données.' }
};

function writeRefusal(result) {
  const reason = String(result?.reason || '');
  const known = WRITE_REASONS[reason];
  const error = new Error(
    known
      ? known.message
      : `Écriture refusée par la base locale${reason ? ` (${reason})` : ''}${result?.permission ? ` · droit requis : ${result.permission}` : ''}.`
  );
  error.code = known ? known.code : 'NOVA_WRITE_DENIED';
  error.reason = reason;
  error.permission = String(result?.permission || '');
  return error;
}

const storage = {
  getItem(key) {
    return ipcRenderer.sendSync('nova-storage-get', String(key));
  },
  setItem(key, value) {
    const result = ipcRenderer.sendSync('nova-storage-set', { key: String(key), value: String(value ?? ''), sessionToken });
    const ok = result === true || result?.ok === true;
    if (!ok) throw writeRefusal(result === false ? { reason: 'session' } : result);
  },
  removeItem(key) {
    const ok = ipcRenderer.sendSync('nova-storage-remove', { key: String(key), sessionToken });
    if (!ok) throw new Error('Suppression refusée par la base locale.');
  },
  clear() {
    const ok = ipcRenderer.sendSync('nova-storage-clear', sessionToken);
    if (!ok) throw new Error('Nettoyage refusé par la base locale.');
  }
};

contextBridge.exposeInMainWorld('novaDesktop', {
  isElectron: true,
  platform: process.platform,
  storage,
  authenticate: async (username, password) => {
    const result = await ipcRenderer.invoke('nova-authenticate', { username: String(username || ''), password: String(password || '') });
    if (result?.ok && result.sessionToken) sessionToken = result.sessionToken;
    return result;
  },
  logout: async () => {
    const result = await ipcRenderer.invoke('nova-logout', sessionToken);
    sessionToken = '';
    return result;
  },
  activateLicense: (licence) => ipcRenderer.invoke('nova-license-activate', { key: String(licence?.key || ''), businessName: String(licence?.businessName || ''), deviceUuid: String(licence?.deviceUuid || ''), sessionToken }),
  getDeviceUuid: () => ipcRenderer.invoke('nova-device-uuid'),
  session: () => ipcRenderer.invoke('nova-session', sessionToken),
  getClockStatus: () => ipcRenderer.invoke('nova-clock-status'),
  getDatabaseInfo: () => ipcRenderer.invoke('nova-database-info'),
  backupDatabase: () => ipcRenderer.invoke('nova-backup-database')
});

import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'bf.iafad.nova',
  appName: 'NOVA Commerce',
  webDir: 'www',
  server: {
    androidScheme: 'https'
  }
};

export default config;

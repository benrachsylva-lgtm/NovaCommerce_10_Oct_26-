@echo off
rem Compilation du Setup Windows - NOVA Commerce (IAFAD Consulting)
setlocal
cd /d "%~dp0"

echo ==============================================
echo  NOVA Commerce - compilation du Setup Windows
echo ==============================================
echo [INFO] La signature de code est desactivee : le Setup sera non signe.
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERREUR] Node.js est introuvable.
  echo Installez Node.js LTS depuis https://nodejs.org/ puis relancez ce script.
  pause
  exit /b 1
)
for /f "tokens=*" %%v in ('node --version') do echo Node.js detecte : %%v

set DEPS_OK=1
if not exist "node_modules\electron\package.json" set DEPS_OK=0
if not exist "node_modules\electron-builder\package.json" set DEPS_OK=0
if not exist "node_modules\better-sqlite3\package.json" set DEPS_OK=0
if not exist "node_modules\prebuild-install\package.json" set DEPS_OK=0
if "%DEPS_OK%"=="0" (
  echo Dependances manquantes ou incompletes. Installation en cours...
  call npm install
  if errorlevel 1 (
    echo [ERREUR] L'installation des dependances a echoue.
    echo Verifiez votre connexion reseau puis relancez ce script.
    pause
    exit /b 1
  )
  if not exist "node_modules\electron-builder\package.json" (
    echo [ERREUR] electron-builder toujours absent apres installation.
    echo Supprimez le dossier node_modules puis relancez ce script.
    pause
    exit /b 1
  )
) else (
  echo Dependances deja installees et completes.
)

echo.
echo Compilation en cours, veuillez patienter...
call npm run desktop:setup
if errorlevel 1 (
  echo.
  echo [ERREUR] La compilation a echoue. Consultez les messages ci-dessus.
  pause
  exit /b 1
)

echo.
echo [OK] Setup genere : NOVA-Commerce-Setup.exe
pause

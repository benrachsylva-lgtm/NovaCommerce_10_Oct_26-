/* Test de non-régression : rapport « Produits par fournisseur » (PDF).
 * Exécute le VRAI code de app.js (regroupement + HTML d'impression)
 * avec un état factice : tri, repli supplierId, orphelins, échappement XSS.
 * Lancer avec : npm run test:supplier-report */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');

const appLines = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8').split('\n');

function extract(marker) {
  const start = appLines.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${marker}`);
  const first = appLines[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${marker}`);
}

const blocks = [
  ...['num', 'money', 'number', 'esc'].map((name) => extract(`  const ${name} = `)),
  ...['categoryName', 'computeSupplierProducts', 'supplierProductsReportHTML', 'printSupplierProducts',
    'nativeBridge', 'isNativeApp', 'printCurrentPage']
    .map((name) => extract(`  function ${name}(`)),
];

const harness = `
${blocks.join('\n')}
// ---------- environnement de test ----------
let state = {
  settings: { businessName: 'Boutique Test' },
  categories: [{ id: 'cat-a', name: 'Alimentation' }],
  suppliers: [
    { id: 'sup-b', name: 'Beta Fournitures', type: 'Entreprise', phone: '+226 70 00 00 01' },
    { id: 'sup-a', name: 'Alpha Gros', type: 'Grossiste', phone: '' },
    { id: 'sup-vide', name: 'Zéro Stock', type: '', phone: '' }
  ],
  products: [
    { id: 'p1', code: 'P-001', name: 'Riz 5kg', categoryId: 'cat-a', supplierId: 'sup-a', purchasePrice: 3900, salePrice: 5200, stock: 10, active: true },
    { id: 'p2', code: 'P-002', name: 'Lait 1L', categoryId: 'cat-a', supplierId: '', purchasePrice: 650, salePrice: 900, stock: 5, active: true },
    { id: 'p3', code: '', name: '<b>XSS</b>', categoryId: 'nope', supplierId: 'sup-b', purchasePrice: 100, salePrice: 200, stock: 0, active: false },
    { id: 'p4', code: 'P-004', name: 'Orphelin', categoryId: 'cat-a', supplierId: '', purchasePrice: 1, salePrice: 2, stock: 3, active: true }
  ],
  supplierProducts: [{ supplierId: 'sup-b', productId: 'p2', createdAt: '', userId: 'system' }]
};
const printRoot = { innerHTML: '' };
const document = { getElementById: (id) => (id === 'print-root' ? printRoot : null) };
let printCalls = 0;
const window = { print: () => { printCalls += 1; } };
const setTimeout = () => 0;
// ---------- scénario ----------
const report = [];
const computed = computeSupplierProducts();
assert.deepStrictEqual(computed.groups.map((g) => g.supplier.name), ['Alpha Gros', 'Beta Fournitures', 'Zéro Stock'], 'fournisseurs triés');
assert.deepStrictEqual(computed.groups[0].items.map((p) => p.id), ['p1'], 'repli supplierId');
assert.strictEqual(computed.groups[1].items.length, 2, 'lien + supplierId cumulés');
const betaNames = computed.groups[1].items.map((p) => p.name);
assert.deepStrictEqual([...betaNames].sort((a, b) => String(a).localeCompare(String(b), 'fr')), betaNames, 'produits triés');
assert.deepStrictEqual(computed.groups[2].items, [], 'fournisseur sans produit');
assert.deepStrictEqual(computed.orphaned.map((p) => p.id), ['p4'], 'orphelin isolé');
report.push('Regroupement: tri + repli + orphelins OK');

const html = supplierProductsReportHTML();
assert.ok(html.includes('<h1>Produits par fournisseur</h1>'), 'titre');
assert.ok(html.includes('Boutique Test'), 'entreprise');
assert.ok(html.includes('3 fournisseur(s)') && html.includes('3 produit(s)'), 'compteurs');
assert.ok(html.includes('Alpha Gros') && html.includes('Beta Fournitures') && html.includes('Zéro Stock'), 'sections');
assert.ok(html.includes('Sans fournisseur attitré'), 'section orphelins');
assert.ok(html.includes('Aucun produit référencé.'), 'section vide explicite');
assert.ok(html.includes('Riz 5kg') && html.includes(money(3900)) && html.includes('P-001'), 'ligne produit');
assert.ok(html.includes('Inactif') && html.includes('Actif'), 'statuts');
assert.ok(html.includes('&lt;b&gt;XSS&lt;/b&gt;'), 'XSS échappé');
assert.ok(!html.includes('<b>XSS</b>'), 'aucun HTML injecté');
assert.ok(html.includes('Sans catégorie'), 'catégorie inconnue');
report.push('HTML: sections + montants + échappement OK');

printSupplierProducts();
assert.ok(printRoot.innerHTML.includes('Produits par fournisseur'), 'print-root rempli');
assert.strictEqual(printCalls, 1, 'impression déclenchée');
report.push('Impression: print-root + window.print OK');
return { report };
`;

const result = new Function('assert', harness)(assert);
console.log('NOVA Commerce — test Rapport fournisseurs');
result.report.forEach((line) => console.log(line));

// ---------- câblage (vérifications statiques) ----------
const appSrc = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const stylesSrc = fs.readFileSync(path.join(__dirname, '..', 'styles.css'), 'utf8');
assert.ok(appSrc.includes("['Rapport fournisseurs', 'Liste des produits fournis par chaque fournisseur', 'suppliers', 'truck', 'blue', 'fournisseurs']"), 'carte hub');
assert.ok(appSrc.includes("data-action=\"${kind === 'fournisseurs' ? 'print-supplier-products' : 'print-full-report'}\""), 'bouton PDF carte');
assert.ok(appSrc.includes("case 'print-supplier-products': printSupplierProducts(); break;"), 'dispatcher');
assert.ok(appSrc.includes('data-action="print-supplier-products">▣ Rapport PDF</button>'), 'bouton vue fournisseurs');
assert.ok(appSrc.includes('function computeSupplierProducts()'), 'calcul');
assert.ok(appSrc.includes('function supplierProductsReportHTML()'), 'HTML');
assert.ok(stylesSrc.includes('.rpt-section-title'), 'CSS sections print');
console.log('Câblage : OK');

console.log('\nTOUS LES TESTS RAPPORT FOURNISSEURS : OK');

/* Test de non-régression : écritures refusées et exports sur Android.
 * Vérifie que app.js et desktop/main.cjs savent EXPLIQUER un refus d'écriture
 * (session expirée, quota, licence, droits), que la session Desktop se renouvelle
 * à l'usage, que les exports passent par la passerelle native sur mobile, et que
 * le journal d'activité reste borné.
 * Lancer avec : npm run test:write */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');

const root = path.join(__dirname, '..');
const appLines = fs.readFileSync(path.join(root, 'app.js'), 'utf8').split('\n');
const mainSrc = fs.readFileSync(path.join(root, 'desktop', 'main.cjs'), 'utf8');
const preloadSrc = fs.readFileSync(path.join(root, 'desktop', 'preload.cjs'), 'utf8');
const appSrc = appLines.join('\n');

function extract(name, source = appLines, kind = 'function', indent = '  ') {
  const marker = `${indent}${kind} ${name}`;
  const start = source.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${name}`);
  const first = source[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < source.length; i += 1) {
    for (const ch of source[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return source.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${name}`);
}

const blocks = [
  ...['NATIVE_PLUGIN_NAME', 'MAX_ACTIVITY_ENTRIES', 'STORAGE_WARN_RATIO', 'LOCAL_STORAGE_CHAR_BUDGET']
    .map((name) => extract(name, appLines, 'const')),
  ...['bytesToBase64', 'textToBase64', 'nativeBridge', 'isNativeApp', 'isPdfLink', 'localStateSize', 'storageUsage', 'trimActivityLog',
    'describeWriteFailure', 'printCurrentPage', 'saveTextFile']
    .map((name) => extract(name)),
];

const harness = `
${blocks.join('\n')}
// ---------- environnement de test ----------
let state = { activities: [], settings: { businessName: 'NOVA Boutique' }, products: [], sales: [] };
let toasts = [];
function toast(title, message, type) { toasts.push({ title, message, type }); }
let currentUser = { id: 'user-admin', name: 'Administrateur', profile: 'Administrateur' };
let openedModal = null;
function openModal(title) { openedModal = title; }
function closeModal() { openedModal = null; }
function esc(value = '') { return String(value); }
function number(value) { return String(value); }
let domNodes = {};
function $(selector) { return domNodes[selector] || null; }
let downloads = 0;
let nativeCalls = [];
const anAppStorage = { getItem: () => '' };
const appStorage = anAppStorage;
function makeWindow(capacitor) {
  const w = {
    Capacitor: capacitor,
    print: () => { w.printCalls = (w.printCalls || 0) + 1; }
  };
  return w;
}
let window = makeWindow(undefined);
let printRootCleaned = false;
const setTimeout = (fn) => { fn(); return 0; };
const document = {
  createElement: () => ({ set href(v) {}, set download(v) {}, click() { downloads += 1; } }),
};
const URL = { createObjectURL: () => 'blob:x', revokeObjectURL: () => {} };
const Blob = function Blob(parts, opts) { this.parts = parts; this.type = opts?.type; };
const btoa = (value) => Buffer.from(value, 'binary').toString('base64');
const TextEncoderImpl = TextEncoder;
const textEncoderRef = TextEncoderImpl;
const unescapeImpl = unescape;

const report = [];
// ---------- 1. Diagnostic d'un refus d'écriture ----------
const sessionError = Object.assign(new Error('Session expirée : reconnectez-vous pour enregistrer.'), { code: 'NOVA_SESSION_EXPIRED' });
assert.strictEqual(describeWriteFailure(sessionError).kind, 'session', 'session détectée');
const quotaError = Object.assign(new Error("Failed to execute 'setItem' on 'Storage': Setting the value of 'nova-commerce-state-v1' exceeded the quota."), { name: 'QuotaExceededError' });
const quotaDiag = describeWriteFailure(quotaError);
assert.strictEqual(quotaDiag.kind, 'quota', 'quota détecté');
assert.ok(quotaDiag.message.includes('%'), 'quota : occupation affichée');
assert.ok(/sauvegarde/i.test(quotaDiag.message), 'quota : action recommandée');
const legacyQuota = describeWriteFailure({ code: 22, message: 'quota' });
assert.strictEqual(legacyQuota.kind, 'quota', 'ancien code 22');
assert.strictEqual(describeWriteFailure(Object.assign(new Error('x'), { code: 'NOVA_LICENSE_READONLY' })).kind, 'license', 'licence');
assert.ok(describeWriteFailure(Object.assign(new Error('x'), { code: 'NOVA_LICENSE_READONLY' })).message.includes('Licence'), 'licence : module indiqué');
assert.strictEqual(describeWriteFailure(Object.assign(new Error('x'), { code: 'NOVA_INTEGRITY' })).kind, 'integrity', 'intégrité');
assert.strictEqual(describeWriteFailure(Object.assign(new Error('x'), { code: 'NOVA_CLOCK_TAMPER' })).kind, 'clock', 'horloge');
assert.strictEqual(describeWriteFailure(Object.assign(new Error('x'), { code: 'NOVA_DB_MISSING' })).kind, 'database', 'base absente');
assert.strictEqual(describeWriteFailure(Object.assign(new Error('droits insuffisants'), { code: 'NOVA_WRITE_DENIED' })).kind, 'permission', 'droits');
const unknown = describeWriteFailure(new Error('panne inattendue'));
assert.strictEqual(unknown.kind, 'unknown', 'cas inconnu conservé');
assert.ok(unknown.message.includes('panne inattendue'), 'cas inconnu : détail technique joint');
assert.ok(!/La session ou la base locale ne permet pas cette écriture\\.$/.test(unknown.message), 'le message générique n\\'est plus seul');
report.push('Diagnostic: session, quota, licence, intégrité, horloge, base, droits, inconnu : OK');

// ---------- 2. Impression : passerelle native prioritaire ----------
window = makeWindow(undefined);
printCurrentPage(null);
assert.strictEqual(window.printCalls, 1, 'navigateur : window.print appelé');
let nativePrinted = 0;
window = makeWindow({
  isNativePlatform: () => true,
  Plugins: { [NATIVE_PLUGIN_NAME]: { printPage: () => { nativePrinted += 1; return Promise.resolve({ completed: true }); } } }
});
let cleanupDone = false;
printCurrentPage(() => { cleanupDone = true; });
assert.strictEqual(window.printCalls, undefined, 'natif : window.print non appelé');
setTimeout(() => {}, 0);
report.push('Impression: navigateur → window.print, mobile → plugin natif : OK');

// ---------- 3. Export : plugin natif ou téléchargement navigateur ----------
window = makeWindow(undefined);
downloads = 0;
saveTextFile('ventes.csv', 'a;b', 'text/csv');
assert.strictEqual(downloads, 1, 'navigateur : lien de téléchargement');
nativeCalls = [];
window = makeWindow({
  isNativePlatform: () => true,
  Plugins: { [NATIVE_PLUGIN_NAME]: { saveToDevice: (options) => { nativeCalls.push(options); return Promise.resolve({ fileName: options.fileName, path: 'Téléchargements/NOVA Commerce/' + options.fileName, uri: 'content://x' }); }, shareFile: () => Promise.resolve({}) } }
});
downloads = 0;
saveTextFile('ventes.csv', 'Libellé;Montant', 'text/csv');
assert.strictEqual(downloads, 0, 'mobile : aucun téléchargement blob (non supporté)');
assert.strictEqual(nativeCalls.length, 1, 'mobile : appel du plugin');
assert.strictEqual(nativeCalls[0].fileName, 'ventes.csv', 'mobile : nom transmis');
assert.strictEqual(Buffer.from(nativeCalls[0].base64, 'base64').toString('utf8'), 'Libellé;Montant', 'mobile : contenu UTF-8 intact');
report.push('Export: navigateur → téléchargement, mobile → plugin natif (UTF-8 vérifié) : OK');

// ---------- 4. Liens PDF embarqués ----------
window = makeWindow(undefined);
assert.strictEqual(isPdfLink({ closest: () => null }), null, 'aucun lien');
const pdfAnchor = { getAttribute: (name) => ({ href: 'guides/guide-caissiers.pdf' }[name]), hasAttribute: () => false };
assert.ok(isPdfLink({ closest: () => pdfAnchor }), 'lien PDF détecté');
assert.strictEqual(isPdfLink({ closest: () => ({ getAttribute: () => 'https://exemple.bf/doc.pdf', hasAttribute: () => false }) }), null, 'lien externe ignoré');
report.push('PDF embarqués: détection et délégation système : OK');

// ---------- 5. Bornage du journal et occupation du stockage ----------
state.activities = Array.from({ length: 4500 }, (unused, index) => ({ id: 'act-' + index }));
const removed = trimActivityLog();
assert.strictEqual(state.activities.length, MAX_ACTIVITY_ENTRIES, 'journal borné');
assert.strictEqual(removed, 1500, 'entrées retirées comptées');
state.activities = [{ id: 'a' }];
assert.strictEqual(trimActivityLog(), 0, 'journal court inchangé');
state = { activities: [], settings: {}, products: [], sales: [] };
const usage = storageUsage();
assert.ok(usage.ratio >= 0 && usage.ratio <= 1, 'ratio d\\'occupation borné');
assert.strictEqual(usage.budget, LOCAL_STORAGE_CHAR_BUDGET, 'budget de référence');
report.push('Journal: plafond ' + MAX_ACTIVITY_ENTRIES + ' entrées, occupation calculée : OK');
return { report };
`;

const report = []; // verrous côté Desktop et câblage
const result = new Function('assert', 'Buffer', 'TextEncoder', 'unescape', harness)(assert, Buffer, TextEncoder, unescape);
result.report.forEach((line) => console.log(' - ' + line));

// ---------- 6. Côté Desktop : motifs de refus et session glissante ----------
const mainLines = mainSrc.split('\n');
const mainBlocks = [
  ...['text', 'number', 'json', 'nowIso', 'addMonths', 'licenseReadOnly', 'safeArray', 'canonical', 'sessionUser',
    'touchSession', 'requireSession', 'collectionChanged', 'movementChange', 'immutableCollectionChange',
    'consumeLicenseTicket', 'isInitialBlankDatabaseState', 'evaluateStateWrite', 'stateWriteAuthorized',
    'validateWriteVolumes', 'hasPermission', 'effectivePermissions', 'observeSystemClock', 'hasRelationalState',
    'buildRelationalState', 'isTrustedSender']
    .map((name) => extract(name, mainLines, 'function', '')),
];

const context = {
  console, Date, Math, JSON, Object, Array, Number, String, Boolean, Set, Map, Buffer, isNaN, parseInt, parseFloat, RegExp, Error,
  sessions: new Map(), licenseTickets: new Map(), mainWindow: { webContents: 'wc' },
  SESSION_TTL_MS: 8 * 60 * 60 * 1000, TRIAL_MONTHS: 3, PROTECTED_ADMIN_USERNAME: '%@PBGgS86D7@N',
  PROTECTED_ADMIN_PASSWORD_HASH: 'hash', FALLBACK_ROLE_PERMISSIONS: { Administrateur: ['*'] },
  event: { sender: 'wc' },
};
const vm = require('node:vm');
vm.createContext(context);
vm.runInContext(mainBlocks.join('\n\n'), context);
vm.runInContext(`
  var CLOCK_OK = true;
  observeSystemClock = function () { return { tampered: !CLOCK_OK, maxObservedAt: Date.now() }; };
  buildRelationalState = function () { return PREVIOUS; };
  hasRelationalState = function () { return true; };
  effectivePermissions = function (userId) { return (PERMS[userId] || []); };
  var PREVIOUS = { license: { trialStartedAt: '2026-01-01T00:00:00.000Z', activated: true }, blankDatabase: false,
    orders: [{ id: 'o1', number: 'CMD-1', status: 'Brouillon', lines: [] }], sales: [], activities: [{ id: 'a1' }] };
  var PERMS = { 'user-admin': ['*'], 'user-vendeur': ['sales.create'] };
`, context);
context.PREVIOUS = JSON.parse(JSON.stringify(context.PREVIOUS));

const expressState = JSON.parse(JSON.stringify(context.PREVIOUS));
expressState.orders = [...expressState.orders, { id: 'o2', number: 'CMD-2', status: 'Brouillon', express: true, lines: [] }, { id: 'o3', number: 'CMD-3', status: 'Brouillon', express: true, lines: [] }];
expressState.activities = [{ id: 'a2' }, ...expressState.activities];

let decision = vm.runInContext('evaluateStateWrite("user-admin", NEXT)', Object.assign(context, { NEXT: expressState }));
assert.strictEqual(decision.allowed, true, 'administrateur autorisé sur les bons express');
assert.strictEqual(decision.reason, '', 'aucun motif de refus');
report.push('Desktop: génération express par l’administrateur autorisée : OK');

decision = vm.runInContext('evaluateStateWrite("user-vendeur", NEXT)', context);
assert.strictEqual(decision.allowed, false, 'profil sans orders.manage refusé');
assert.strictEqual(decision.reason, 'droits', 'motif « droits »');
assert.strictEqual(decision.permission, 'orders.manage', 'droit manquant identifié');
report.push('Desktop: refus motivé « droits » + droit requis orders.manage : OK');

vm.runInContext('CLOCK_OK = false', context);
decision = vm.runInContext('evaluateStateWrite("user-admin", NEXT)', context);
assert.strictEqual(decision.reason, 'clock', 'horloge signalée');
vm.runInContext('CLOCK_OK = true', context);

vm.runInContext('PREVIOUS.license = { trialStartedAt: "2026-01-01T00:00:00.000Z", activated: false }', context);
context.PREVIOUS = vm.runInContext('PREVIOUS', context);
context.NEXT.license = { trialStartedAt: '2026-01-01T00:00:00.000Z', activated: false };
decision = vm.runInContext('evaluateStateWrite("user-admin", NEXT)', context);
assert.strictEqual(decision.allowed, false, 'essai expiré refusé');
assert.strictEqual(decision.reason, 'licence-lecture-seule', 'motif licence explicite');
report.push('Desktop: essai expiré → motif « licence-lecture-seule » : OK');

// session glissante
vm.runInContext("sessions.set('jeton', { userId: 'user-admin', expiresAt: Date.now() + 1000 })", context);
const before = vm.runInContext("sessions.get('jeton').expiresAt", context);
vm.runInContext("touchSession('jeton')", context);
const after = vm.runInContext("sessions.get('jeton').expiresAt", context);
assert.ok(after > before, 'session prolongée à l’usage');
assert.ok(after - Date.now() > 8 * 60 * 60 * 1000 - 5000, 'nouvelle échéance de 8 h');
vm.runInContext("sessions.set('perime', { userId: 'user-admin', expiresAt: Date.now() - 1 })", context);
assert.strictEqual(vm.runInContext("touchSession('perime')", context), false, 'session périmée non prolongée');
assert.strictEqual(vm.runInContext("requireSession(event, 'perime', true)", context), false, 'session périmée sans état relationnel vierge');
report.push('Desktop: session glissante (renouvelée à l’usage, périmée refusée) : OK');

// ---------- 7. Câblage statique ----------
assert.ok(appSrc.includes("case 'purge-activity': purgeActivityLog(); break;"), 'action de purge câblée');
assert.ok(appSrc.includes('data-action="purge-activity"'), 'bouton de purge présent');
assert.ok(appSrc.includes('function requestSessionRecovery('), 'reprise de session présente');
assert.ok(appSrc.includes('isClockTampered(true)'), 'saveState n’écrit plus deux fois l’état');
assert.ok(!/window\\.print\\(\\);\\n\\s*setTimeout/.test(appSrc), 'aucun window.print isolé hors passerelle');
assert.ok(mainSrc.includes('evaluateStateWrite'), 'main.cjs expose evaluateStateWrite');
assert.ok(mainSrc.includes("reason: 'session'"), 'main.cjs motive le refus de session');
assert.ok(preloadSrc.includes('NOVA_SESSION_EXPIRED'), 'preload : erreur de session typée');
assert.ok(preloadSrc.includes('NOVA_LICENSE_READONLY'), 'preload : erreur de licence typée');
const mainActivity = fs.readFileSync(path.join(root, 'android/app/src/main/java/bf/iafad/nova/MainActivity.java'), 'utf8');
assert.ok(mainActivity.includes('registerPlugin(NovaExportPlugin.class)'), 'plugin Android enregistré');
const pluginJava = fs.readFileSync(path.join(root, 'android/app/src/main/java/bf/iafad/nova/NovaExportPlugin.java'), 'utf8');
['saveToDevice', 'saveAsset', 'openAsset', 'shareFile', 'printPage'].forEach((method) => {
  assert.ok(pluginJava.includes('public void ' + method + '('), 'méthode native ' + method + ' présente');
});
assert.ok(pluginJava.includes('createPrintDocumentAdapter'), 'impression via PrintManager');
assert.ok(pluginJava.includes('MediaStore.Downloads'), 'écriture dans Téléchargements (Android 10+)');
report.push('Câblage: action, plugin Android, motifs remontés au JS : OK');

report.forEach((line) => console.log(' - ' + line));
console.log('\nTOUS LES TESTS ÉCRITURE / EXPORTS : OK');

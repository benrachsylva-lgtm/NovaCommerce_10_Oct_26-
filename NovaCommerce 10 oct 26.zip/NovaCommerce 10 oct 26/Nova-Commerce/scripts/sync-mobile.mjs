import { mkdirSync, copyFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('..', import.meta.url));
const mobileDir = join(root, 'www');
const files = ['index.html', 'styles.css', 'app.js', 'manifest.json', 'service-worker.js', 'icon.svg', 'user-icon.png', 'nova-loading.png'];

mkdirSync(mobileDir, { recursive: true });
for (const file of files) copyFileSync(join(root, file), join(mobileDir, file));
mkdirSync(join(mobileDir, 'guides'), { recursive: true });
for (const file of readdirSync(join(root, 'guides'))) copyFileSync(join(root, 'guides', file), join(mobileDir, 'guides', file));
console.log(`NOVA Commerce: ${files.length} fichiers synchronisés vers www/`);

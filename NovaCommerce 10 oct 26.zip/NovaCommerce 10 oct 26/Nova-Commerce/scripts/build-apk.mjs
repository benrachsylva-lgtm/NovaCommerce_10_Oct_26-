import { existsSync, copyFileSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('..', import.meta.url));
const variant = (process.argv[2] || 'debug').toLowerCase();
const production = String(process.env.NOVA_BUILD_CHANNEL || '').toLowerCase() === 'production';
const hasOfficialSigning = Boolean(process.env.NOVA_ANDROID_KEYSTORE_PATH && process.env.NOVA_ANDROID_KEYSTORE_PASSWORD && process.env.NOVA_ANDROID_KEY_ALIAS && process.env.NOVA_ANDROID_KEY_PASSWORD);
if (production && variant !== 'release') throw new Error('Un build commercial Android doit utiliser la variante release.');
if (production && !hasOfficialSigning) throw new Error('Signature Android officielle absente : définissez NOVA_ANDROID_KEYSTORE_PATH, NOVA_ANDROID_KEYSTORE_PASSWORD, NOVA_ANDROID_KEY_ALIAS et NOVA_ANDROID_KEY_PASSWORD.');
const androidDir = join(root, 'android');
const wrapper = process.platform === 'win32' ? 'gradlew.bat' : './gradlew';
const result = spawnSync(wrapper, [`assemble${variant[0].toUpperCase()}${variant.slice(1)}`], { cwd: androidDir, stdio: 'inherit', shell: process.platform === 'win32' });
if (result.error) {
  console.error(`ERREUR : impossible de lancer ${wrapper} (${result.error.message}).`);
  if (process.platform !== 'win32') console.error('Sur Linux/macOS, rendez le wrapper exécutable : chmod +x android/gradlew');
  process.exit(1);
}
if (result.status !== 0) process.exit(result.status || 1);

const apkName = variant === 'release' ? (hasOfficialSigning ? 'NOVA-Commerce-release.apk' : 'NOVA-Commerce-release-unsigned.apk') : 'NOVA-Commerce-debug.apk';
const outputDir = join(androidDir, 'app', 'build', 'outputs', 'apk', variant);
const apkCandidates = variant === 'release'
  ? [join(outputDir, 'app-release.apk'), join(outputDir, 'app-release-unsigned.apk')]
  : [join(outputDir, `app-${variant}.apk`)];
const apkPath = apkCandidates.find((candidate) => existsSync(candidate));
if (!apkPath) throw new Error(`APK introuvable dans : ${outputDir}`);
const destination = join(root, apkName);
copyFileSync(apkPath, destination);
console.log(`APK généré : ${apkName}`);

// Contrôle de conformité obligatoire : l'erreur d'installation Android 11+
// « resources.arsc to be stored uncompressed and aligned on a 4-byte boundary »
// ne peut provenir que d'un APK reconditionné après la compilation. On le
// vérifie donc systématiquement, et le build échoue si l'APK n'est pas conforme.
const verificationArgs = [join(root, 'scripts', 'verify-apk.mjs'), destination];
if (variant === 'release' && !hasOfficialSigning) verificationArgs.push('--allow-unsigned');
const verification = spawnSync(process.execPath, verificationArgs, { cwd: root, stdio: 'inherit' });
if (verification.status !== 0) {
  console.error('\nCompilation terminée mais APK NON CONFORME : corrigez avant toute installation.');
  process.exit(verification.status || 1);
}
console.log('Cet APK peut être installé sur Android 11 et versions supérieures sans erreur « resources.arsc ».');
console.log('Ne modifiez jamais l’APK avec un outil tiers (ré-archivage, « optimisation », éditeur d’APK) : cela casserait cette conformité.');

/**
 * Correctif « NSIS sans Wine » pour les builds Windows réalisés depuis Linux.
 *
 * electron-builder génère l'uninstaller de l'installeur NSIS en **exécutant** une
 * première fois l'installeur (`NsisTarget.computeScriptAndSignUninstaller`). Sous
 * Windows, l'exécution est native ; sous Linux/macOS, electron-builder réclame
 * Wine — ce qui échoue sur une machine de compilation nue (`wine process failed
 * ENOENT`) alors que le seul besoin est d'extraire l'uninstaller.
 *
 * electron-builder embarque déjà un lecteur d'installeur NSIS en JavaScript
 * (`UninstallerReader`, utilisé pour son contournement macOS Catalina) qui
 * remplit exactement ce rôle, sans Wine. Ce script applique ce remplacement dans
 * `node_modules`, de façon idempotente. Il est appelé automatiquement par
 * `scripts/build-desktop.mjs` sur les plateformes non Windows.
 *
 * Aucun effet sous Windows : rien n'est modifié.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);

if (process.platform === 'win32') {
  console.log('Correctif NSIS : plateforme Windows, aucune modification nécessaire.');
  process.exit(0);
}

let target;
try {
  target = require.resolve('app-builder-lib/out/targets/nsis/NsisTarget.js');
} catch (_) {
  console.error('Correctif NSIS : app-builder-lib introuvable (lancez npm install).');
  process.exit(0);
}

const source = readFileSync(target, 'utf8');
if (source.includes('UninstallerReader.exec(installerPath, uninstallerPath)') && source.includes('SANS WINE')) {
  console.log('Correctif NSIS : déjà appliqué.');
  process.exit(0);
}

const needle = [
  '            const wineVm = new WineVm_1.WineVmManager((_a = packager.config.toolsets) === null || _a === void 0 ? void 0 : _a.wine);',
  '            await wineVm.exec(installerPath, [], { env: { __COMPAT_LAYER: "RunAsInvoker" } });'
].join('\n');

if (!source.includes(needle)) {
  console.error('Correctif NSIS : structure inattendue dans NsisTarget.js — correctif ignoré.');
  console.error('Le build continuera : s’il réclame Wine, exécutez la compilation sur Windows.');
  process.exit(0);
}

const replacement = [
  '            // --- CORRECTIF NOVA (SANS WINE) : extraction de l’uninstaller par le lecteur JS intégré.',
  '            await nsisUtil_1.UninstallerReader.exec(installerPath, uninstallerPath);',
  '            // --- FIN DU CORRECTIF NOVA.'
].join('\n');

writeFileSync(target, source.replace(needle, replacement));
console.log('Correctif NSIS appliqué : uninstaller extrait sans Wine (lecteur JavaScript).');

/* Test de non-régression : correctifs d'audit pré-production (M1, M3, m3, m5, m7-m10, m8). m6 est couvert par test-designer.
 * Exécute les VRAIES fonctions de app.js : pagination virtuelle des tables,
 * neutralisation CSV, version des sauvegardes, stockage corrompu.
 * Lancer avec : npm run test:prod */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');

const appLines = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8').split('\n');

function extract(marker) {
  const start = appLines.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${marker}`);
  const first = appLines[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${marker}`);
}

const blocks = [
  ...['STORAGE_KEY', 'PROTECTED_ADMIN_USERNAME', 'SEED_PASSWORD_HASHES', 'CORRUPT_BACKUP_SLOTS',
    'DEFAULT_ROLE_PERMISSIONS', 'APP_VERSION', 'BACKUP_SCHEMA_VERSION', 'PAGED_TABLE_SIZE',
    'num', 'isoDate', 'isoDateTime', 'seedState'].map((name) => extract(`  const ${name} = `)),
  ...['dateCode', 'isPasswordHash', 'normalizeUsers', 'normalizeRoles', 'normalizeSupplierProducts',
    'normalizeProductStock', 'preserveCorruptStorage', 'loadState', 'decodeEntities', 'splitTableRows',
    'pagedRowMeta', 'pagedVisible', 'pagedSlice', 'pagedTbody', 'pageButtonList', 'sanitizeCsvCell',
    'validateBackupData', 'buildBackupPayload', 'backupFileStamp'].map((name) => extract(`  function ${name}(`))
];

const harness = `
${blocks.join('\n')}
// ---------- environnement de test ----------
let pagedRowStore = {};
let tablePages = {};
let storageCorruptInfo = null;
const __store = new Map();
let appStorage = {
  getItem: (k) => (__store.has(k) ? __store.get(k) : null),
  setItem: (k, v) => { __store.set(k, String(v)); },
  removeItem: (k) => { __store.delete(k); }
};
let currentUser = null;
let state = null;
const report = [];
// ---------- M3 : pagination virtuelle ----------
// decodeEntities
assert.strictEqual(decodeEntities('a&#39;b&quot;c&lt;d&gt;e&amp;f'), 'a\\'b"c<d>e&f');
assert.strictEqual(decodeEntities('L\\'atelier'), 'L\\'atelier');
assert.strictEqual(decodeEntities(''), '');
// splitTableRows
const three = '<tr data-filter-row><td>1</td></tr><tr data-filter-row><td>2</td></tr><tr><td>3</td></tr>';
assert.strictEqual(splitTableRows(three).length, 3);
assert.strictEqual(splitTableRows('').length, 0);
const nested = '<tr><td><table><tr><td>in</td></tr></table></td></tr><tr><td>out</td></tr>';
const nestedSplit = splitTableRows(nested);
assert.strictEqual(nestedSplit.length, 2);
assert.ok(nestedSplit[0].includes('<table>'));
// pagedRowMeta
const meta = pagedRowMeta('<tr data-filter-row data-text="l&#39;atelier &amp; fils" data-category="CAT-01" data-state="En cours"><td><span class="status-badge success">Validée</span></td></tr>');
assert.strictEqual(meta.text, "l'atelier & fils");
assert.strictEqual(meta.category, 'cat-01');
assert.strictEqual(meta.state, 'en cours');
assert.deepStrictEqual(meta.badges, ['validée']);
// pagedTbody : 25 lignes -> tranches de 10
const rows25 = Array.from({ length: 25 }, (_, i) => '<tr data-filter-row data-text="ligne ' + (i + 1) + '"><td>' + (i + 1) + '</td></tr>').join('');
tablePages = {};
const page1 = pagedTbody('test-table', rows25);
assert.strictEqual(pagedRowStore['test-table'].length, 25);
assert.strictEqual(splitTableRows(page1).length, 10);
assert.ok(page1.includes('>1</td>') && page1.includes('>10</td>'));
tablePages['test-table'] = 3;
const page3 = pagedTbody('test-table', rows25);
assert.strictEqual(splitTableRows(page3).length, 5);
assert.ok(page3.includes('>21</td>') && page3.includes('>25</td>'));
// filtre simulé : 'ligne 1' matche 1, 10-19 (11 lignes)
pagedRowStore['test-table'].forEach((r) => { r.searchMatch = r.text.includes('ligne 1'); });
assert.strictEqual(pagedVisible('test-table').length, 11);
tablePages['test-table'] = 1;
assert.strictEqual(splitTableRows(pagedSlice('test-table', 1)).length, 10);
assert.strictEqual(splitTableRows(pagedSlice('test-table', 2)).length, 1);
// tableau vide
assert.strictEqual(pagedTbody('empty-table', ''), '');
assert.strictEqual(pagedRowStore['empty-table'].length, 0);
// pageButtonList compacte
assert.deepStrictEqual(pageButtonList(1, 1), [1]);
assert.deepStrictEqual(pageButtonList(3, 5), [1, 2, 3, 4, 5]);
assert.deepStrictEqual(pageButtonList(1, 400), [1, 2, '…', 399, 400]);
assert.deepStrictEqual(pageButtonList(200, 400), [1, 2, '…', 199, 200, 201, '…', 399, 400]);
assert.deepStrictEqual(pageButtonList(400, 400), [1, 2, '…', 399, 400]);
assert.ok(pageButtonList(200, 400).length <= 9);
report.push('M3 pagination virtuelle: 25 lignes -> tranches 10/10/5, filtre simulé 11 lignes, pager compact (400 pages -> 7-9 boutons)');
// ---------- m3 : neutralisation CSV ----------
[['=cmd|/c', "'=cmd|/c"], ['+33', "'+33"], ['-5', "'-5"], ['@x', "'@x"], ['|dde', "'|dde"],
 ['normal', 'normal'], ['12', '12'], ['a=b', 'a=b'], ['', '']].forEach(([input, expected]) => assert.strictEqual(sanitizeCsvCell(input), expected));
assert.strictEqual(sanitizeCsvCell('\\tind'), "'\\tind");
report.push('m3 CSV: 10 cellules (6 à risque neutralisées, 4 intactes)');
// ---------- m8 : version des sauvegardes ----------
const fake = { products: [{ id: 'p1' }], sales: [], clients: [], suppliers: [], stores: [], categories: [], orders: [], settings: {} };
const payload = buildBackupPayload(fake);
const parsed = JSON.parse(payload.json);
assert.strictEqual(parsed.appVersion, '1.0.0');
assert.strictEqual(parsed.schemaVersion, 1);
assert.strictEqual(parsed.kind, 'sauvegarde-base');
assert.deepStrictEqual(parsed.state, fake);
assert.ok(/^nova-commerce-sauvegarde-\\d{8}-\\d{4}\\.json$/.test(payload.filename));
assert.strictEqual(validateBackupData(parsed), '');
assert.ok(validateBackupData({ ...parsed, schemaVersion: 99 }).includes('plus récente'));
assert.strictEqual(validateBackupData({ products: [], sales: [], clients: [], suppliers: [], stores: [], categories: [], orders: [], settings: {} }), '');
assert.ok(validateBackupData({ products: [] }).length > 0);
assert.ok(validateBackupData(null).length > 0);
report.push('m8 sauvegarde: version 1.0.0/schema 1 émis, schéma futur rejeté, ancien format accepté');
// ---------- M1 : stockage corrompu ----------
// preserveCorruptStorage + rotation des 3 emplacements
__store.clear();
const info1 = preserveCorruptStorage('{corrompu-1}');
assert.strictEqual(info1.backupKey, 'nova-corrupt-backup-1');
assert.strictEqual(JSON.parse(__store.get('nova-corrupt-backup-1')).raw, '{corrompu-1}');
preserveCorruptStorage('{corrompu-2}');
preserveCorruptStorage('{corrompu-3}');
assert.strictEqual(__store.size, 3);
const aged = JSON.parse(__store.get('nova-corrupt-backup-1'));
aged.savedAt = '2000-01-01T00:00:00.000Z';
__store.set('nova-corrupt-backup-1', JSON.stringify(aged));
const info4 = preserveCorruptStorage('{corrompu-4}');
assert.strictEqual(info4.backupKey, 'nova-corrupt-backup-1');
assert.strictEqual(__store.size, 3);
// loadState : stockage vide
__store.clear();
storageCorruptInfo = null;
let s = loadState();
assert.strictEqual(storageCorruptInfo, null);
assert.strictEqual(s.products.length, 100);
assert.strictEqual(s.initialSetupCompleted, false);
// loadState : JSON corrompu
__store.set(STORAGE_KEY, '{json invalide}');
storageCorruptInfo = null;
s = loadState();
assert.ok(storageCorruptInfo && storageCorruptInfo.backupKey === 'nova-corrupt-backup-1');
assert.strictEqual(s.products.length, 100);
assert.strictEqual(JSON.parse(__store.get('nova-corrupt-backup-1')).raw, '{json invalide}');
// loadState : sauvegarde valide préservée
__store.clear();
const custom = seedState();
custom.settings.businessName = 'Boutique Test Audit';
__store.set(STORAGE_KEY, JSON.stringify(custom));
storageCorruptInfo = null;
s = loadState();
assert.strictEqual(storageCorruptInfo, null);
assert.strictEqual(s.settings.businessName, 'Boutique Test Audit');
assert.strictEqual(s.products.length, 100);
report.push('M1 stockage corrompu: rotation 3 emplacements, JSON invalide préservé + signalé, sauvegarde valide restaurée');
return { report };
`;

const result = new Function('assert', harness)(assert);
console.log('NOVA Commerce — test Correctifs pré-production (M1, M3, m3, m5, m7-m10, m8)');
result.report.forEach((line) => console.log(line));

// ---------- mineures m5, m7, m9, m10 (vérifications statiques) ----------
const appSrcFixes = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const readmeFixes = fs.readFileSync(path.join(__dirname, '..', 'README.md'), 'utf8');
const analyse = fs.readFileSync(path.join(__dirname, '..', 'ANALYSE-CRITIQUE.md'), 'utf8');
assert.ok(analyse.includes('## 5. Limites résiduelles'), 'm5 analyse créée');
assert.ok(!readmeFixes.includes('`ANALYSE-CRITIQUE.md`.\nrestantes est disponible'), 'm5 README dédupliqué');
const mdRefs = [...readmeFixes.matchAll(/`([A-Z][A-Z0-9-]*\.md)`/g)].map((m) => m[1]);
assert.ok(mdRefs.length >= 2, 'm5 références détectées');
[...new Set(mdRefs)].forEach((doc) => assert.ok(fs.existsSync(path.join(__dirname, '..', doc)), `m5 ${doc} existe`));
['index.html', 'styles.css', 'app.js', 'manifest.json', 'service-worker.js', 'icon.svg', 'user-icon.png', 'nova-loading.png'].forEach((file) => {
  const root = fs.readFileSync(path.join(__dirname, '..', file));
  assert.ok(root.equals(fs.readFileSync(path.join(__dirname, '..', 'www', file))), `m7 www/${file} synchronisé`);
  assert.ok(root.equals(fs.readFileSync(path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'assets', 'public', file))), `m7 android/${file} synchronisé`);
});
assert.ok(appSrcFixes.includes('réinitialisable si l’utilisateur vide les données du navigateur'), 'm9 commentaire garde');
assert.ok(readmeFixes.includes('Limite connue : sur PWA/Android, la garde anti-recul'), 'm9 README');
const srcLines = appSrcFixes.split('\n');
['panel', 'metricCard', 'openModal'].forEach((helper) => {
  const def = srcLines.findIndex((line) => line.includes(`function ${helper}(`));
  assert.ok(def > 4, `m10 ${helper} défini`);
  assert.ok(srcLines.slice(def - 4, def).join('\n').includes('HTML DE CONFIANCE'), `m10 convention ${helper}`);
});
assert.ok(appSrcFixes.includes('Helper sûr par construction'), 'm10 statusBadge');
console.log('Mineures m5/m7/m9/m10 : OK');
console.log('\nTOUS LES TESTS CORRECTIFS : OK');

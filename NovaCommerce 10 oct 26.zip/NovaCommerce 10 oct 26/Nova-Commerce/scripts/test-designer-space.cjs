/* Test de non-régression : Espace concepteur (Nous contacter).
 * Exécute le VRAI code de app.js (verrou par code + matrice 27 modules + bascules)
 * avec un faux DOM minimal pour la sidebar.
 * Lancer avec : npm run test:designer */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');
const { subtle } = require('node:crypto').webcrypto;

const appLines = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8').split('\n');

function extract(marker) {
  const start = appLines.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${marker}`);
  const first = appLines[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${marker}`);
}

function extractBlock(startMarker, endLine) {
  const start = appLines.findIndex((line) => line.includes(startMarker));
  const end = appLines.findIndex((line, idx) => idx > start && line === endLine);
  if (start < 0 || end < 0) throw new Error(`bloc introuvable: ${startMarker}`);
  return appLines.slice(start, end + 1).join('\n');
}

const blocks = [
  ...['PROTECTED_ADMIN_USERNAME', 'SEED_PASSWORD_HASHES', 'DESIGNER_CODE_SALT', 'DESIGNER_CODE_DIGEST', 'num', 'esc', 'uid',
    'isoDate', 'isoDateTime', 'number', 'seedState', 'VIEW_PERMISSIONS', 'VIEW_META',
    'MODULE_MANAGE_PERMISSIONS', 'DEFAULT_ROLE_PERMISSIONS'
  ].map((name) => extract(`  const ${name} = `)),
  extractBlock('  const ROLE_MATRIX_MODULES = [', '  ];'),
  ...['dateCode', 'pageHeading', 'disabledModules', 'isModuleDisabled', 'designerModuleLabel',
    'setModuleEnabled', 'setAllModulesEnabled', 'currentUserId',
    'addActivity', 'applySidebarVisibility', 'renderDesignerSpace', 'renderContact', 'bytesToHex'
  ].map((name) => extract(`  function ${name}(`)),
  extract('function sha256Hex('),
  extract('function verifyDesignerCode('),
  extract('function unlockDesignerSpace('),
];

const harness = `
${blocks.join('\n')}
// ---------- environnement de test ----------
let designerUnlocked = false;
let currentUser = { id: 'user-admin', username: 'admin', profile: 'Administrateur' };
let state = null;
let requirePermission = () => true;
let isReadOnly = () => false;
const toasts = [];
const toast = (t, m, k) => { toasts.push([t, m, k]); };
let renderCalls = 0;
const render = () => { renderCalls += 1; };
const renderLicenceRequestCard = () => '<!-- carte licence (couverte par test-licence) -->';
const saveState = () => true;
let activeView = 'dashboard';
let sidebarCollapsed = false;
const can = () => true;
let fakeLinks = [];
let fakeGroups = [];
const $$ = (sel) => (sel === '.nav-link' ? fakeLinks : sel === '.nav-group' ? fakeGroups : []);
const window = { crypto: { subtle } };
const lastToast = () => toasts[toasts.length - 1];
return (async () => {
// ---------- scénario ----------
state = seedState();
const report = [];
report.push('Seed: disabledModules=' + JSON.stringify(disabledModules()));
assert.strictEqual(designerUnlocked, false, 'verrouillé par défaut');
assert.deepStrictEqual(disabledModules(), []);
assert.deepStrictEqual(state.settings.disabledModules, []);
assert.strictEqual(isModuleDisabled('sales'), false);
let html = renderDesignerSpace();
assert.ok(html.includes('Code d’accès'), 'champ code');
assert.ok(html.includes('id="designer-form"'), 'formulaire');
assert.ok(!html.includes('data-designer-module'), 'matrice masquée');
assert.ok(html.includes('Verrouillé'), 'badge verrouillé');
assert.ok(renderContact().includes('Espace concepteur'), 'section contact');
assert.ok(renderContact().includes('id="designer-form"'), 'formulaire via contact');
// mauvais code
assert.strictEqual(await unlockDesignerSpace({ querySelector: () => ({ value: 'mauvais-code' }) }), false);
assert.strictEqual(designerUnlocked, false);
assert.strictEqual(lastToast()[0], 'Code incorrect');
assert.strictEqual(lastToast()[2], 'error');
assert.strictEqual(await unlockDesignerSpace({ querySelector: () => null }), false);
// bon code
const actsBefore = state.activities.length;
// Le code en clair n’existe que dans ce test (jamais dans le client livré).
assert.strictEqual(await unlockDesignerSpace({ querySelector: () => ({ value: 'K4$zN8!pT2@w' }) }), true);
assert.strictEqual(designerUnlocked, true);
assert.strictEqual(state.activities.length, actsBefore + 1);
assert.strictEqual(state.activities[0].module, 'Concepteur');
assert.strictEqual(state.activities[0].action, 'Déverrouillage de l’espace concepteur');
assert.ok(renderCalls >= 1, 'rendu après déverrouillage');
html = renderDesignerSpace();
assert.strictEqual((html.match(/data-designer-module="/g) || []).length, 27, '27 cases');
assert.ok(!html.includes('data-designer-module="guide"'), 'guide exclu');
assert.ok(!html.includes('data-designer-module="contact"'), 'contact exclu');
assert.ok(html.includes('Déverrouillé'), 'badge déverrouillé');
assert.ok(html.includes('27 / 27 modules disponibles'), 'compteur plein');
['Exploitation', 'Catalogue', 'Stocks', 'Finance', 'Administration'].forEach((g) => assert.ok(html.includes(g), 'groupe ' + g));
report.push('Verrou: refus + acceptation + matrice 27 OK');
// bascule unitaire
assert.strictEqual(setModuleEnabled('sales', false), true);
assert.deepStrictEqual(disabledModules(), ['sales']);
assert.strictEqual(isModuleDisabled('sales'), true);
assert.strictEqual(state.activities[0].action, 'Désactivation d’un module');
assert.strictEqual(state.activities[0].element, 'Historique des ventes');
html = renderDesignerSpace();
assert.ok(!html.split('data-designer-module="sales"')[1].split('>')[0].includes('checked'), 'sales décochée');
assert.ok(html.split('data-designer-module="clients"')[1].split('>')[0].includes('checked'), 'clients cochée');
assert.ok(html.includes('26 / 27 modules disponibles'), 'compteur partiel');
assert.strictEqual(setModuleEnabled('sales', true), true);
assert.deepStrictEqual(disabledModules(), []);
assert.strictEqual(state.activities[0].action, 'Activation d’un module');
report.push('Bascule: on/off + rendu + journal OK');
// refus permission
requirePermission = () => false;
const callsBefore = renderCalls;
assert.strictEqual(setModuleEnabled('sales', false), false);
assert.deepStrictEqual(disabledModules(), []);
assert.strictEqual(renderCalls, callsBefore, 'pas de rendu');
requirePermission = () => true;
// lecture seule
isReadOnly = () => true;
assert.strictEqual(setModuleEnabled('sales', false), false);
assert.deepStrictEqual(disabledModules(), []);
isReadOnly = () => false;
report.push('Gardes: permission + lecture seule OK');
// tout (dés)activer
setAllModulesEnabled(false);
assert.strictEqual(disabledModules().length, 27);
assert.ok(renderDesignerSpace().includes('0 / 27 modules disponibles'), 'compteur vide');
setAllModulesEnabled(true);
assert.deepStrictEqual(disabledModules(), []);
requirePermission = () => false;
setAllModulesEnabled(false);
assert.deepStrictEqual(disabledModules(), [], 'tout-désactiver gardé');
requirePermission = () => true;
// libellés
assert.strictEqual(designerModuleLabel('sales'), 'Historique des ventes');
assert.strictEqual(designerModuleLabel('dashboard'), 'Tableau de bord');
assert.strictEqual(designerModuleLabel('xxx'), 'xxx');
// sidebar (faux DOM)
const fakeLink = (view) => ({ dataset: { view }, hidden: false, classList: { toggle: () => {} }, querySelector: () => null, title: '' });
const lDash = fakeLink('dashboard');
const lSales = fakeLink('sales');
const lClients = fakeLink('clients');
fakeLinks = [lDash, lSales, lClients];
const g1 = { querySelectorAll: () => [lSales, lClients], hidden: false };
const g2 = { querySelectorAll: () => [lDash], hidden: false };
fakeGroups = [g1, g2];
setModuleEnabled('sales', false);
setModuleEnabled('clients', false);
applySidebarVisibility();
assert.strictEqual(lSales.hidden, true);
assert.strictEqual(lClients.hidden, true);
assert.strictEqual(lDash.hidden, false);
assert.strictEqual(g1.hidden, true, 'section masquée');
assert.strictEqual(g2.hidden, false);
setModuleEnabled('sales', true);
applySidebarVisibility();
assert.strictEqual(lSales.hidden, false);
assert.strictEqual(g1.hidden, false, 'section réaffichée');
setModuleEnabled('clients', true);
report.push('Sidebar: liens + sections OK');
return { report };
})();
`;

async function main() {
const result = await new Function('assert', 'subtle', harness)(assert, subtle);
console.log('NOVA Commerce — test Espace concepteur');
result.report.forEach((line) => console.log(line));
console.log('Verrou + matrice + bascules + sidebar : OK');

// ---------- câblage (vérifications statiques) ----------
const appSrc = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
assert.ok(appSrc.includes("const DESIGNER_CODE_DIGEST = '1b8c98db9ec18607f22c3e38ab9e71b18fe8f713713404e8da907af586d9c0e6';"), 'empreinte salée');
assert.ok(appSrc.includes('async function verifyDesignerCode(value)'), 'comparaison quasi-constant-time');
assert.ok(!appSrc.includes('K4$zN8!pT2@w'), 'aucun code en clair dans le client');
assert.ok(appSrc.includes('if (isModuleDisabled(view)) {'), 'garde navigate');
assert.ok(appSrc.includes("if (isModuleDisabled(activeView)) activeView = isModuleDisabled('dashboard') ? 'contact' : 'dashboard';"), 'garde render');
assert.ok(appSrc.includes('applySidebarVisibility();'), 'appel visibilité');
assert.ok(appSrc.includes("'designer-enable-all': 'settings.manage'"), 'droit tout-activer');
assert.ok(appSrc.includes("'designer-disable-all': 'settings.manage'"), 'droit tout-désactiver');
const readOnlySet = appSrc.match(/const READ_ONLY_ACTIONS = new Set\(\[([^\]]+)\]\)/)[1];
assert.ok(readOnlySet.includes("'designer-enable-all'") && readOnlySet.includes("'designer-disable-all'"), 'lecture seule');
assert.ok(!readOnlySet.includes("'designer-lock'"), 'verrouillage toujours permis');
assert.ok(appSrc.includes("case 'designer-enable-all': setAllModulesEnabled(true); break;"), 'dispatcher activer');
assert.ok(appSrc.includes("case 'designer-disable-all': setAllModulesEnabled(false); break;"), 'dispatcher désactiver');
assert.ok(appSrc.includes("case 'designer-lock': designerUnlocked = false;"), 'dispatcher verrou');
assert.ok(appSrc.includes('unlockDesignerSpace(designerForm)'), 'liaison formulaire');
assert.ok(appSrc.includes("box.dataset.designerModule, box.checked"), 'liaison cases');
assert.strictEqual((appSrc.match(/designerUnlocked = false/g) || []).length, 4, 'init + logout + verrou + inactivité');
assert.ok(appSrc.includes('disabledModules: [], inactivityLockMinutes: 15, ticketPrinter:'), 'seed settings');
assert.ok(appSrc.includes('${renderDesignerSpace()}`;'), 'accroche contact');
assert.ok(appSrc.includes("addActivity('Concepteur', 'Déverrouillage de l’espace concepteur', currentUser?.username || 'session', 'Matrice des modules affichée')"), 'journal sans le code');
assert.ok(appSrc.includes('L’Espace concepteur, déverrouillé par code'), 'guide');
console.log('Câblage : OK (gardes, droits, dispatcher, liaisons, guide)');

// ---------- styles présents ----------
const cssSrc = fs.readFileSync(path.join(__dirname, '..', 'styles.css'), 'utf8');
['.nav-link[hidden]', '.nav-group[hidden]', '.designer-panel', '.designer-grid'].forEach((cls) => assert.ok(cssSrc.includes(cls), `style ${cls}`));
console.log('Styles concepteur : OK');
console.log('\nTOUS LES TESTS CONCEPTEUR : OK');

}

main().catch((error) => { console.error(error); process.exit(1); });

/* Contrôle de conformité d'un APK Android — NOVA Commerce
 *
 * Empêche l'erreur d'installation :
 *   « Targeting R+ (version 30 and above) requires resources.arsc to be
 *     stored uncompressed and aligned on a 4-byte boundary »
 *
 * Cette erreur n'apparaît JAMAIS avec un APK produit par Gradle. Elle survient
 * lorsque l'APK est reconditionné après coup : décompression/recompression par un
 * outil tiers (« optimiseur d'APK », éditeur d'APK, simple `zip`), ou signature
 * effectuée avant l'alignement. Ce contrôle lit l'archive octet par octet — sans
 * aucune dépendance — et vérifie ce que vérifie Android :
 *
 *   1. resources.arsc présent, STOCKÉ (non compressé) et aligné sur 4 octets ;
 *   2. toutes les entrées non compressées alignées sur 4 octets ;
 *   3. bibliothèques .so non compressées alignées sur la page (16 Ko) ;
 *   4. bloc de signature APK v2/v3 présent ;
 *   5. l'application livrée contient bien le code attendu (passerelle native) ;
 *   6. `zipalign` et `apksigner` du SDK confirment, lorsqu'ils sont disponibles.
 *
 * Usage :
 *   node scripts/verify-apk.mjs NOVA-Commerce-release.apk
 *   node scripts/verify-apk.mjs NOVA-Commerce-release.apk --fix [--keystore chemin.p12]
 * Lancer avec : npm run apk:verify -- NOVA-Commerce-release.apk
 */
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { inflateRawSync } from 'node:zlib';
import { basename, join } from 'node:path';
import { spawnSync } from 'node:child_process';

const FILE_SIGNATURE = {
  local: 0x04034b50,
  central: 0x02014b50,
  end: 0x06054b50
};
const SIG_BLOCK_MAGIC = 'APK Sig Block 42';
const PAGE_ALIGNMENT = 16384; // 16 Ko : requis par Android 15 pour les .so non compressés

function readApk(path) {
  const buffer = readFileSync(path);
  const end = findEndOfCentralDirectory(buffer);
  if (!end) throw new Error('Archive illisible : fin de répertoire central introuvable (fichier tronqué ?).');
  return { buffer, ...readCentralDirectory(buffer, end), end };
}

function findEndOfCentralDirectory(buffer) {
  const minimum = Math.max(0, buffer.length - 66000);
  for (let offset = buffer.length - 22; offset >= minimum; offset -= 1) {
    if (buffer.readUInt32LE(offset) === FILE_SIGNATURE.end) return offset;
  }
  return null;
}

function readCentralDirectory(buffer, end) {
  const count = buffer.readUInt16LE(end + 10);
  let offset = buffer.readUInt32LE(end + 16);
  const centralDirectoryOffset = offset;
  const entries = [];
  for (let index = 0; index < count; index += 1) {
    if (buffer.readUInt32LE(offset) !== FILE_SIGNATURE.central) break;
    const method = buffer.readUInt16LE(offset + 10);
    const compressedSize = buffer.readUInt32LE(offset + 20);
    const uncompressedSize = buffer.readUInt32LE(offset + 24);
    const nameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);
    const localOffset = buffer.readUInt32LE(offset + 42);
    const name = buffer.subarray(offset + 46, offset + 46 + nameLength).toString('utf8');
    entries.push({
      name,
      method,
      compressedSize,
      uncompressedSize,
      localOffset,
      dataOffset: localDataOffset(buffer, localOffset),
      stored: method === 0
    });
    offset += 46 + nameLength + extraLength + commentLength;
  }
  return { entries, centralDirectoryOffset };
}

function localDataOffset(buffer, localOffset) {
  if (buffer.readUInt32LE(localOffset) !== FILE_SIGNATURE.local) return -1;
  const nameLength = buffer.readUInt16LE(localOffset + 26);
  const extraLength = buffer.readUInt16LE(localOffset + 28);
  return localOffset + 30 + nameLength + extraLength;
}

function aligned(value, boundary) { return value >= 0 && value % boundary === 0; }

/** Normalise une empreinte SHA-256 : minuscules, sans séparateurs. */
function normaliserEmpreinte(value) {
  return String(value || '').replace(/[^0-9a-fA-F]/g, '').toLowerCase();
}

function findBuildTool(name) {
  const roots = [process.env.ANDROID_HOME, process.env.ANDROID_SDK_ROOT, join(process.env.HOME || '', 'AppData/Local/Android/Sdk')].filter(Boolean);
  const extension = process.platform === 'win32' ? '.bat' : '';
  for (const root of roots) {
    const buildTools = join(root, 'build-tools');
    if (!existsSync(buildTools)) continue;
    const versions = readdirSync(buildTools).sort().reverse();
    for (const version of versions) {
      const candidate = join(buildTools, version, name + extension);
      if (existsSync(candidate)) return candidate;
    }
  }
  return null;
}

function run(command, args) {
  const result = spawnSync(command, args, { encoding: 'utf8', shell: process.platform === 'win32' });
  return { ok: result.status === 0, output: `${result.stdout || ''}${result.stderr || ''}`.trim() };
}

function verify(path, options = {}) {
  const problems = [];
  const notices = [];
  const { buffer, entries, centralDirectoryOffset } = readApk(path);

  const arcs = entries.find((entry) => entry.name === 'resources.arsc');
  if (!arcs) {
    problems.push('resources.arsc est absent de l’APK.');
  } else {
    if (!arcs.stored) problems.push('resources.arsc est compressé : Android 11+ refuse l’installation (doit être stocké sans compression).');
    if (!aligned(arcs.dataOffset, 4)) problems.push(`resources.arsc n’est pas aligné sur 4 octets (offset des données : ${arcs.dataOffset}).`);
  }

  const misalignedStored = entries.filter((entry) => entry.stored && !aligned(entry.dataOffset, 4));
  if (misalignedStored.length) problems.push(`${misalignedStored.length} entrée(s) non compressée(s) mal alignée(s) (ex. ${misalignedStored[0].name}).`);

  const sharedLibraries = entries.filter((entry) => entry.name.endsWith('.so') && entry.stored);
  const misalignedLibs = sharedLibraries.filter((entry) => !aligned(entry.dataOffset, PAGE_ALIGNMENT));
  if (misalignedLibs.length) problems.push(`${misalignedLibs.length} bibliothèque(s) .so non compressée(s) non alignée(s) sur 16 Ko (Android 15).`);

  const signingBlock = buffer.subarray(centralDirectoryOffset - 16, centralDirectoryOffset).toString('latin1') === SIG_BLOCK_MAGIC;
  const jarSigned = entries.some((entry) => /^META-INF\/.*\.(RSA|DSA|EC)$/i.test(entry.name));
  if (!signingBlock) {
    if (jarSigned) notices.push('Signature v1 (JAR) détectée mais pas de bloc v2/v3 : la protection contre la modification est plus faible.');
    else if (options.allowUnsigned) notices.push('APK non signé (variante « release non signée ») : il reste à signer avec le certificat officiel avant diffusion.');
    else problems.push('Aucune signature détectée : l’APK ne peut pas être installé.');
  }

  const appBundle = entries.find((entry) => entry.name === 'assets/public/app.js');
  if (!appBundle) {
    problems.push('assets/public/app.js est absent : l’interface web n’a pas été copiée dans l’APK.');
  } else {
    const start = appBundle.dataOffset;
    const slice = buffer.subarray(start, start + Math.min(appBundle.uncompressedSize || appBundle.compressedSize, 4_000_000));
    const text = appBundle.stored ? slice.toString('utf8') : tryInflate(slice);
    if (text && !text.includes('NovaExport')) notices.push('app.js ne contient pas la passerelle d’export native (NovaExport) : les exports Android seront inopérants.');
    if (text && !text.includes('Session expirée')) notices.push('app.js ne contient pas le correctif de reprise de session.');
  }

  const javaClass = entries.find((entry) => entry.name === 'classes.dex');
  if (!javaClass) problems.push('classes.dex est absent : l’application native ne peut pas démarrer.');

  const zipalign = findBuildTool('zipalign');
  if (zipalign) {
    const check = run(zipalign, ['-c', '-p', '-v', '4', path]);
    if (!check.ok) problems.push('zipalign du SDK refuse l’APK : ' + (check.output.split('\n').filter(Boolean).pop() || 'alignement invalide'));
    else notices.push('zipalign -c -p -v 4 : conforme.');
  } else {
    notices.push('zipalign introuvable (ANDROID_HOME non défini) : contrôle interne uniquement.');
  }

  const apksigner = findBuildTool('apksigner');
  if (apksigner) {
    const check = run(apksigner, ['verify', '--verbose', path]);
    if (check.ok) {
      notices.push('apksigner : signature vérifiée.');
    } else if (options.allowUnsigned && !signingBlock && !jarSigned) {
      notices.push('apksigner : APK non signé — à signer avec le certificat officiel (zipalign déjà conforme).');
    } else {
      problems.push('apksigner refuse l’APK : ' + check.output.split('\n').slice(0, 2).join(' '));
    }

    // Épinglage du certificat : garantit que l'APK est bien signé avec la clé de
    // l'éditeur (et non une clé de débogage ou une autre clé), condition pour que
    // les mises à jour s'installent par-dessus les versions déjà distribuées.
    const attendue = normaliserEmpreinte(options.certSha256 || process.env.NOVA_CERT_SHA256);
    if (attendue && check.ok) {
      const certificats = run(apksigner, ['verify', '--print-certs', path]);
      const trouvees = [...certificats.output.matchAll(/certificate SHA-256 digest:\s*([0-9a-fA-F:]+)/g)]
        .map((m) => normaliserEmpreinte(m[1]));
      if (trouvees.includes(attendue)) {
        notices.push('certificat signataire conforme à l’empreinte attendue (' + attendue.slice(0, 16) + '…).');
      } else {
        problems.push('certificat signataire inattendu : l’APK n’est pas signé avec la clé de l’éditeur (attendu ' + attendue.slice(0, 16) + '…, trouvé ' + (trouvees[0] || 'aucun').slice(0, 16) + '…).');
      }
    }
  }

  return { problems, notices, arcs, entries, options };
}

function tryInflate(slice) {
  try { return inflateRawSync(slice).toString('utf8'); } catch (_) { return null; }
}

function repair(path, options) {
  const zipalign = findBuildTool('zipalign');
  const apksigner = findBuildTool('apksigner');
  if (!zipalign) throw new Error('zipalign est introuvable : définissez ANDROID_HOME puis relancez.');
  if (!options.keystore) throw new Error('Réparation refusée sans --keystore : après alignement, l’APK doit être re-signé (la signature précédente devient invalide).');
  const aligned = path.replace(/\.apk$/i, '') + '-aligned.apk';
  const signed = path.replace(/\.apk$/i, '') + '-repaired.apk';
  console.log(`\n→ Alignement : ${basename(aligned)}`);
  const align = run(zipalign, ['-p', '-f', '4', path, aligned]);
  if (!align.ok) throw new Error('zipalign a échoué : ' + align.output);
  console.log('→ Signature : ' + basename(signed));
  const sign = run(apksigner, ['sign', '--ks', options.keystore, '--ks-pass', `pass:${options.password || ''}`,
    ...(options.alias ? ['--ks-key-alias', options.alias] : []),
    '--out', signed, aligned]);
  if (!sign.ok) throw new Error('apksigner a échoué : ' + sign.output);
  console.log(`\nAPK réparé : ${signed}`);
  console.log('Rappel : la signature a changé — l’APK doit être désinstallé/réinstallé, et publié avec le même certificat que les versions précédentes.');
}

const target = process.argv[2];
if (!target) {
  console.error('Usage : node scripts/verify-apk.mjs <fichier.apk> [--cert-sha256 empreinte] [--fix] [--keystore chemin] [--alias nom] [--password mdp]');
  process.exit(2);
}
if (!existsSync(target)) {
  console.error(`APK introuvable : ${target}`);
  process.exit(2);
}
const args = process.argv.slice(3);
const options = {
  fix: args.includes('--fix'),
  allowUnsigned: args.includes('--allow-unsigned'),
  certSha256: valueOf(args, '--cert-sha256'),
  keystore: valueOf(args, '--keystore'),
  alias: valueOf(args, '--alias'),
  password: valueOf(args, '--password')
};
function valueOf(list, name) {
  const index = list.indexOf(name);
  return index >= 0 ? list[index + 1] : '';
}

const result = verify(target, options);
console.log(`\n=== CONTRÔLE APK : ${basename(target)} (${(readFileSync(target).length / 1048576).toFixed(2)} Mo) ===`);
if (result.arcs) {
  console.log(`  resources.arsc : ${result.arcs.stored ? 'non compressé' : 'COMPRESSÉ'} · offset des données ${result.arcs.dataOffset} · alignement 4 octets ${aligned(result.arcs.dataOffset, 4) ? 'OK' : 'NON'}`);
}
console.log(`  entrées : ${result.entries.length}`);
result.notices.forEach((line) => console.log('  · ' + line));
if (result.problems.length) {
  console.log('\n  ANOMALIES DÉTECTÉES :');
  result.problems.forEach((line) => console.log('  ✗ ' + line));
  if (options.fix) {
    repair(target, options);
  } else {
    console.log('\n  Correction : reconstruire avec « npm run mobile:apk:release » (Gradle aligne et signe correctement).');
    console.log('  Si l’APK a été reconditionné par un outil tiers, réparez-le : node scripts/verify-apk.mjs <apk> --fix --keystore <keystore>');
  }
  process.exit(1);
}
console.log('\n✓ APK CONFORME : resources.arsc non compressé et aligné sur 4 octets → aucune erreur d’installation « Targeting R+ (version 30 et au-dessus) » sur Android 11 et versions supérieures.');

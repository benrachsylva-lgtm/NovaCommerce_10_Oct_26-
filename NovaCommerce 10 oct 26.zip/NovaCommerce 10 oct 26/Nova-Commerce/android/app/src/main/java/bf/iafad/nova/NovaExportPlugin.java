package bf.iafad.nova;

import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Passerelle native NOVA Commerce (Android).
 *
 * Android WebView ne sait ni enregistrer un fichier téléchargé depuis un lien
 * « blob: » / « a[download] », ni ouvrir la boîte de dialogue d'impression
 * (window.print() est sans effet). Ce plugin fournit ces deux capacités :
 *
 *   - saveToDevice : écrit un export (CSV, JSON de sauvegarde…) dans
 *     Téléchargements/NOVA Commerce, puis propose le partage ;
 *   - saveAsset   : copie un document livré avec l'application (guides PDF) ;
 *   - openAsset   : ouvre un PDF embarqué dans la visionneuse du système ;
 *   - shareFile   : partage un fichier déjà enregistré ;
 *   - printPage   : impression via PrintManager (donne accès à « Enregistrer en PDF »).
 *
 * Le code est autonome : aucune dépendance npm supplémentaire n'est requise
 * (le pont JavaScript est injecté automatiquement par Capacitor).
 */
@CapacitorPlugin(name = "NovaExport")
public class NovaExportPlugin extends Plugin {

  private static final String DOWNLOAD_FOLDER = "NOVA Commerce";

  // ------------------------------------------------------------------ écriture

  @PluginMethod
  public void saveToDevice(PluginCall call) {
    String fileName = sanitizeFileName(call.getString("fileName"));
    String mimeType = valueOr(call.getString("mimeType"), "application/octet-stream");
    String base64 = call.getString("base64");
    String text = call.getString("text");

    if (fileName == null) {
      call.reject("Nom de fichier manquant.");
      return;
    }
    byte[] bytes;
    try {
      if (base64 != null) {
        bytes = Base64.decode(base64, Base64.DEFAULT);
      } else if (text != null) {
        bytes = text.getBytes("UTF-8");
      } else {
        call.reject("Aucune donnée à enregistrer.");
        return;
      }
    } catch (Exception error) {
      call.reject("Contenu illisible : " + error.getMessage());
      return;
    }
    writeToDevice(call, fileName, mimeType, bytes);
  }

  @PluginMethod
  public void saveAsset(PluginCall call) {
    String assetPath = call.getString("assetPath");
    String fileName = valueOr(call.getString("fileName"), assetPath == null ? null : new File(assetPath).getName());
    if (assetPath == null) {
      call.reject("Chemin du document manquant.");
      return;
    }
    String mimeType = valueOr(call.getString("mimeType"), guessMimeType(fileName));
    byte[] bytes = readAsset(assetPath);
    if (bytes == null) {
      call.reject("Document introuvable dans l’application : " + assetPath);
      return;
    }
    writeToDevice(call, sanitizeFileName(fileName), mimeType, bytes);
  }

  @PluginMethod
  public void openAsset(PluginCall call) {
    String assetPath = call.getString("assetPath");
    if (assetPath == null) {
      call.reject("Chemin du document manquant.");
      return;
    }
    byte[] bytes = readAsset(assetPath);
    if (bytes == null) {
      call.reject("Document introuvable dans l’application : " + assetPath);
      return;
    }
    try {
      File target = new File(getContext().getCacheDir(), sanitizeFileName(new File(assetPath).getName()));
      try (OutputStream out = new FileOutputStream(target)) {
        out.write(bytes);
      }
      Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", target);
      Intent intent = new Intent(Intent.ACTION_VIEW);
      intent.setDataAndType(uri, guessMimeType(target.getName()));
      intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
      Intent chooser = Intent.createChooser(intent, "Ouvrir le document");
      chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      getContext().startActivity(chooser);
      JSObject result = new JSObject();
      result.put("opened", true);
      call.resolve(result);
    } catch (ActivityNotFoundException error) {
      call.reject("Aucune application ne peut ouvrir ce document sur cet appareil.");
    } catch (Exception error) {
      call.reject("Ouverture impossible : " + error.getMessage());
    }
  }

  @PluginMethod
  public void shareFile(PluginCall call) {
    String path = call.getString("path");
    String uriText = call.getString("uri");
    try {
      Uri uri = uriText != null ? Uri.parse(uriText) : fileUriFromPath(path);
      if (uri == null) {
        call.reject("Fichier à partager introuvable.");
        return;
      }
      Intent intent = new Intent(Intent.ACTION_SEND);
      intent.setType(valueOr(call.getString("mimeType"), "application/octet-stream"));
      intent.putExtra(Intent.EXTRA_STREAM, uri);
      intent.setClipData(android.content.ClipData.newRawUri("NOVA Commerce", uri));
      intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      Intent chooser = Intent.createChooser(intent, "Partager le fichier");
      chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      getContext().startActivity(chooser);
      call.resolve(new JSObject());
    } catch (Exception error) {
      call.reject("Partage impossible : " + error.getMessage());
    }
  }

  // ------------------------------------------------------------------ impression

  @PluginMethod
  public void printPage(final PluginCall call) {
    final String jobName = valueOr(call.getString("jobName"), "NOVA Commerce");
    getActivity().runOnUiThread(() -> {
      try {
        WebView webView = getBridge().getWebView();
        if (webView == null) {
          call.reject("Page non disponible pour l’impression.");
          return;
        }
        PrintManager printManager = (PrintManager) getContext().getSystemService(Context.PRINT_SERVICE);
        if (printManager == null) {
          call.reject("Service d’impression indisponible sur cet appareil.");
          return;
        }
        // minSdk 22 : la variante avec nom de travail est toujours disponible.
        PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(jobName);
        PrintAttributes attributes = new PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build();
        printManager.print(jobName, new ResolvingPrintAdapter(adapter, call), attributes);
      } catch (Exception error) {
        call.reject("Impression impossible : " + error.getMessage());
      }
    });
  }

  /**
   * Enveloppe l'adaptateur d'impression du WebView pour prévenir la page une fois
   * le travail terminé : le JavaScript peut alors retirer le document imprimable du DOM.
   */
  private static class ResolvingPrintAdapter extends PrintDocumentAdapter {
    private final PrintDocumentAdapter delegate;
    private final PluginCall call;
    private boolean resolved = false;

    ResolvingPrintAdapter(PrintDocumentAdapter delegate, PluginCall call) {
      this.delegate = delegate;
      this.call = call;
    }

    private void resolveOnce() {
      if (resolved) return;
      resolved = true;
      try {
        JSObject result = new JSObject();
        result.put("completed", true);
        call.resolve(result);
      } catch (Exception ignored) {
        // la page a pu être déchargée : sans conséquence
      }
    }

    @Override
    public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                         CancellationSignal cancellationSignal, LayoutResultCallback callback, Bundle extras) {
      delegate.onLayout(oldAttributes, newAttributes, cancellationSignal, callback, extras);
    }

    @Override
    public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                        CancellationSignal cancellationSignal, WriteResultCallback callback) {
      delegate.onWrite(pages, destination, cancellationSignal, callback);
    }

    @Override
    public void onStart() {
      delegate.onStart();
    }

    @Override
    public void onFinish() {
      delegate.onFinish();
      resolveOnce();
    }
  }

  // ------------------------------------------------------------------ utilitaires

  private void writeToDevice(PluginCall call, String fileName, String mimeType, byte[] bytes) {
    if (fileName == null) {
      call.reject("Nom de fichier invalide.");
      return;
    }
    try {
      JSObject result = new JSObject();
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ContentResolver resolver = getContext().getContentResolver();
        ContentValues values = new ContentValues();
        values.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName);
        values.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mimeType);
        values.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + DOWNLOAD_FOLDER);
        values.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) {
          call.reject("Le système a refusé la création du fichier.");
          return;
        }
        try (OutputStream out = resolver.openOutputStream(uri)) {
          if (out == null) throw new IOException("flux indisponible");
          out.write(bytes);
          out.flush();
        }
        ContentValues done = new ContentValues();
        done.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0);
        resolver.update(uri, done, null, null);
        result.put("path", Environment.DIRECTORY_DOWNLOADS + "/" + DOWNLOAD_FOLDER + "/" + fileName);
        result.put("uri", uri.toString());
      } else {
        File folder = getContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if (folder == null) folder = getContext().getFilesDir();
        File target = new File(folder, fileName);
        try (OutputStream out = new FileOutputStream(target)) {
          out.write(bytes);
          out.flush();
        }
        Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", target);
        result.put("path", target.getAbsolutePath());
        result.put("uri", uri.toString());
      }
      result.put("fileName", fileName);
      result.put("size", bytes.length);
      call.resolve(result);
    } catch (Exception error) {
      call.reject("Enregistrement impossible : " + error.getMessage());
    }
  }

  private Uri fileUriFromPath(String path) {
    if (path == null) return null;
    File file = new File(path);
    if (!file.exists()) return null;
    return FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", file);
  }

  private byte[] readAsset(String assetPath) {
    String clean = assetPath.startsWith("/") ? assetPath.substring(1) : assetPath;
    try (InputStream stream = getContext().getAssets().open("public/" + clean)) {
      ByteArrayOutputStream buffer = new ByteArrayOutputStream();
      byte[] chunk = new byte[8192];
      int read;
      while ((read = stream.read(chunk)) != -1) buffer.write(chunk, 0, read);
      return buffer.toByteArray();
    } catch (Exception error) {
      return null;
    }
  }

  private static String sanitizeFileName(String value) {
    if (value == null) return null;
    String clean = value.replaceAll("[\\\\/:*?\"<>|]", "-").trim();
    return clean.isEmpty() ? null : clean;
  }

  private static String valueOr(String value, String fallback) {
    return value == null || value.trim().isEmpty() ? fallback : value;
  }

  private static String guessMimeType(String fileName) {
    String name = fileName == null ? "" : fileName.toLowerCase();
    if (name.endsWith(".pdf")) return "application/pdf";
    if (name.endsWith(".csv")) return "text/csv";
    if (name.endsWith(".json")) return "application/json";
    if (name.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    if (name.endsWith(".png")) return "image/png";
    if (name.endsWith(".jpg") || name.endsWith(".jpeg")) return "image/jpeg";
    if (name.endsWith(".txt")) return "text/plain";
    return "application/octet-stream";
  }
}

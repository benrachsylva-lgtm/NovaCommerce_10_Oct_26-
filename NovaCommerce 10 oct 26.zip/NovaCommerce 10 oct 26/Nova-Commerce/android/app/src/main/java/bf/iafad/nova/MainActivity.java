package bf.iafad.nova;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

  @Override
  public void onCreate(Bundle savedInstanceState) {
    // Déclaré AVANT super.onCreate() : Capacitor expose ensuite
    // window.Capacitor.Plugins.NovaExport au JavaScript de l'application.
    registerPlugin(NovaExportPlugin.class);
    super.onCreate(savedInstanceState);
  }
}

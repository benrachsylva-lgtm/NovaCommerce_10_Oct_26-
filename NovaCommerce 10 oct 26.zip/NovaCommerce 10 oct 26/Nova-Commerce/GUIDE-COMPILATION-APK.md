# Guide de compilation APK Android — NOVA Commerce

> Procédure complète. Le résumé des commandes est dans le README
> (§ Construire la PWA et Android, § Signature Android de production).

## 1. Prérequis (machine de build)

- **Node.js 20+** et `npm` ;
- **JDK 17** (`JAVA_HOME` défini, `java -version` OK) ;
- **Android SDK** (commandlinetools + platform-tools + une plateforme Android 34+),
  `ANDROID_HOME` (ou `ANDROID_SDK_ROOT`) défini et licence acceptées (`sdkmanager --licenses`) ;
- dépendances installées à la racine du projet : `npm install`
  (fournit `@capacitor/cli`, `@capacitor/core`, `@capacitor/android`).

Vérification rapide :

```bash
node --version && npx cap --version && java -version
```

## 2. Exports, impression et plugin natif (NOVA-Export)

Les exports de l'application (CSV « Excel », sauvegarde JSON) et l'impression des
documents (tickets, bons de commande, devis, rapports PDF) ne peuvent pas s'appuyer
sur les fonctions du navigateur, absentes d'Android WebView : `a[download]` sur une
URL `blob:` ne déclenche aucun téléchargement et `window.print()` n'ouvre aucune
boîte de dialogue.

Le projet embarque donc une passerelle native, **sans aucune dépendance npm
supplémentaire** :

| Fichier | Rôle |
|---|---|
| `android/app/src/main/java/bf/iafad/nova/NovaExportPlugin.java` | plugin Capacitor : `saveToDevice`, `saveAsset`, `openAsset`, `shareFile`, `printPage` |
| `android/app/src/main/java/bf/iafad/nova/MainActivity.java` | `registerPlugin(NovaExportPlugin.class)` avant `super.onCreate()` |

Comportement obtenu dans l'APK :

- les exports sont écrits dans **Téléchargements / NOVA Commerce** (Android 10+) puis
  proposés au partage ; sur Android 9 et antérieur, ils sont écrits dans le dossier
  Documents de l'application, puis partagés ;
- les rapports et documents s'impriment via **PrintManager** (impression réelle ou
  « Enregistrer en PDF ») ;
- les guides PDF livrés avec l'application s'ouvrent dans la visionneuse du système.

> ⚠️ Ces fichiers Java sont **indispensables** : un APK fabriqué sans eux perd les
> exports et l'impression. Vérifier leur présence avant de compiler, et ne jamais
> écraser le dossier `android/app/src/main/java/`. La compilation Gradle force
> l'encodage UTF-8 (`android/app/build.gradle`) pour préserver les messages accentués.

Vérification après compilation : ouvrir **Journal d'activité → Exports CSV**, exporter
une table, puis vérifier qu'un fichier `nova-*.csv` apparaît dans Téléchargements.

## 3. Icône de l'application

L'icône est générée depuis une seule image de marque
(`assets/icon-app-rayira.webp`) par :

```bash
npm run icons:android                          # utilise assets/icon-app-rayira.webp
python3 scripts/generate-icons.py chemin/image.png   # ou une autre image (carrée)
```

Le script applique la **géométrie officielle des icônes adaptatives Android** : la
marque est inscrite dans la zone visible de 66 dp de la toile de 108 dp, sur un fond
bleu marine `#172554` (`values/ic_launcher_background.xml`). Elle reste donc entière
quel que soit le masque du lanceur (cercle, goutte, écusson, carré arrondi).

Produits dans `android/app/src/main/res/` :

| Fichier | Rôle |
|---|---|
| `mipmap-*/ic_launcher_foreground.png` (108 → 432 px) | couche avant de l'icône adaptative (API 26+) |
| `mipmap-*/ic_launcher.png` (48 → 192 px) | icône classique (API < 26) |
| `mipmap-*/ic_launcher_round.png` (48 → 192 px) | icône ronde (API < 26), bord transparent |
| `values/ic_launcher_background.xml` | couleur de la couche de fond adaptative |

Après génération, **recompiler l'APK** (`npm run mobile:apk:debug`) : les icônes sont
embarquées dans le paquet, aucun redémarrage du lanceur n'est nécessaire côté
utilisateur. Pour changer l'image, remplacer `assets/icon-app-rayira.webp` (carré,
≥ 512 px) puis relancer les deux commandes.

## 4. Builds de test (sans certificat)

```bash
npm run mobile:apk:debug     # → NOVA-Commerce-debug.apk (clé debug Android)
npm run mobile:apk:release   # → NOVA-Commerce-release-unsigned.apk (NON signé)
```

Chaque commande resynchronise `www/` puis `npx cap sync android` avant de lancer
Gradle (`scripts/build-apk.mjs`). Les deux artefacts sont des **builds de test** :
ne jamais les présenter comme des livrables commerciaux.

## 5. Build commercial signé (production)

1. Préparer un **keystore commercial hors du dépôt** (ne jamais commiter
   keystore, mots de passe ni certificats). Exemple de création :
   ```bash
   keytool -genkeypair -v -keystore C:\secrets\nova-commerce-release.jks \
     -alias nova-commerce -keyalg RSA -keysize 4096 -validity 9125
   ```
2. Fournir les variables **uniquement au job de build sécurisé** :
   ```text
   NOVA_BUILD_CHANNEL=production
   NOVA_ANDROID_KEYSTORE_PATH=C:\secrets\nova-commerce-release.jks
   NOVA_ANDROID_KEYSTORE_PASSWORD=<coffre de secrets>
   NOVA_ANDROID_KEY_ALIAS=nova-commerce
   NOVA_ANDROID_KEY_PASSWORD=<coffre de secrets>
   ```
3. Compiler :
   ```bash
   npm run mobile:apk:release
   ```
   Le script refuse tout build `production` sans les quatre paramètres
   (`scripts/build-apk.mjs`) et produit `NOVA-Commerce-release.apk`.
4. Vérifier la signature et archiver l’empreinte SHA-256 du certificat :
   ```bash
   apksigner verify --verbose NOVA-Commerce-release.apk
   node scripts/verify-apk.mjs NOVA-Commerce-release.apk --cert-sha256 <empreinte SHA-256 du certificat>
   keytool -list -v -keystore C:\secrets\nova-commerce-release.p12 -alias nova-commerce
   ```

> Le type de keystore n’a pas d’importance : `.jks` (JKS) comme `.p12` (PKCS#12)
> sont acceptés par Gradle et `apksigner`. En PKCS#12, le mot de passe du magasin
> et celui de la clé sont identiques (contrainte du format).
>
> **Épinglage du certificat** : l’option `--cert-sha256` (ou la variable
> `NOVA_CERT_SHA256`) fait échouer le contrôle si l’APK n’est pas signé par la clé
> attendue. À utiliser pour toute livraison commerciale afin qu’aucun APK signé
> avec une clé de débogage (ou une autre clé) ne soit diffusé par erreur.

## 6. Garantie : erreur « resources.arsc » (Android 11 et versions supérieures)

L'erreur d'installation

```text
Targeting R+ (version 30 and above) requires resources.arsc to be stored
uncompressed and aligned on a 4-byte boundary
```

**ne peut pas provenir d'un APK produit par Gradle** : Android Gradle Plugin écrit
`resources.arsc` sans compression et aligne toutes les entrées sur 4 octets avant
de signer. Elle apparaît quand un APK est **reconditionné après la compilation** :
ré-archivage par un outil tiers (« optimiseur d'APK », éditeur d'APK, `zip -r`,
décompression/recompression), ou signature effectuée **avant** l'alignement.

Chaque build du dépôt est donc contrôlé automatiquement à la fin de
`scripts/build-apk.mjs` ; la compilation **échoue** si l'APK n'est pas conforme.

```bash
npm run apk:verify -- NOVA-Commerce-release.apk   # contrôle d'un APK existant
```

Le contrôle (`scripts/verify-apk.mjs`) lit l'archive octet par octet — sans
dépendance externe — et vérifie : `resources.arsc` présent, **non compressé** et
**aligné sur 4 octets** ; toutes les entrées non compressées alignées ; les `.so`
alignés sur 16 Ko (Android 15) ; la présence d'un bloc de signature v2/v3 ; le
contenu réel de l'application (`NovaExport`, correctif de session). Il
confirme ensuite avec le SDK (`zipalign -c -p -v 4`, `apksigner verify`).

### Ordre impératif

```text
compiler (Gradle)  →  zipalign -p -f 4  →  apksigner sign  →  apksigner verify
```

Ne **jamais** modifier l'APK après la signature (ni ré-archivage, ni `zipalign`,
ni édition du manifeste) : cela invaliderait la signature v2 et casserait
l'installation. Si un APK a été abîmé, la réparation est intégrée :

```bash
node scripts/verify-apk.mjs APK-abimé.apk --fix \
  --keystore C:\secrets\nova-commerce-release.jks --alias nova-commerce --password <mdp>
```

Elle réaligne **puis** re-signe (l'APK portant la signature de réparation doit
être réinstallé sur les appareils de test ; pour une mise à jour commerciale, il
faut conserver le même certificat que les versions publiées).

> La clé de signature de l’éditeur est conservée **hors du dépôt** (jamais
> commitée) : voir le dossier de sauvegarde du poste de build et son
> `LISEZ-MOI-SIGNATURE.md`. Sa perte rend impossible toute mise à jour
> s’installant par-dessus une version déjà publiée.

## 7. Règles de livraison (rappel)

- Toujours compiler via `mobile:apk:debug` / `mobile:apk:release` (resync incluse).
- Ne jamais commiter d’assets `android/app/src/main/assets/public/` périmés
  (contrôlé par `npm run test:prod`, garde m7).
- `android/app/build/`, `www/`, `desktop-dist/` et `*.apk` ne sont pas versionnés.

## 8. Dépannage

| Symptôme | Cause probable | Action |
|---|---|---|
| `SDK location not found` | `ANDROID_HOME` absent | Définir `ANDROID_HOME` ou `local.properties` |
| `Unsupported class file major version` | Mauvais JDK | Utiliser JDK 17 (`JAVA_HOME`) |
| Assets obsolètes dans l’APK | Sync oubliée | `npm run mobile:sync:capacitor` puis recompiler |
| `Signature Android officielle absente` | Variables manquantes | Revoir §5 (build production uniquement) |
| `Targeting R+ … resources.arsc` | APK reconditionné après compilation | Ne jamais ré-archiver l'APK ; recompiler via `mobile:apk:release` |
| `Missing META-INF/MANIFEST.MF` / `DOES NOT VERIFY` | Signature avant alignement | Réaligner **puis** re-signer : `node scripts/verify-apk.mjs <apk> --fix --keystore …` |

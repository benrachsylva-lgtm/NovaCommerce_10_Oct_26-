/* Vérification finale sur la version LIVRÉE (index.html + app.js réels). */
const puppeteer = require('puppeteer');
(async () => {
  const b = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const p = await b.newPage();
  const errors = [];
  p.on('pageerror', (e) => errors.push(e.message.slice(0, 160)));
  p.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 160)); });
  await p.goto('http://127.0.0.1:4173/index.html', { waitUntil: 'domcontentloaded' });
  await new Promise((r) => setTimeout(r, 6500));
  const state = await p.evaluate(() => ({
    loadingVisible: !!document.querySelector('#loading-screen') && !document.querySelector('#loading-screen')?.hidden,
    setupVisible: !!document.querySelector('#first-run-screen') && !document.querySelector('#first-run-screen')?.hidden,
    loginVisible: !!document.querySelector('#login-screen') && !document.querySelector('#login-screen')?.hidden,
    stored: (localStorage.getItem('nova-commerce-state-v1') || '').length,
    printRootOffscreen: getComputedStyle(document.getElementById('print-root')).left,
    hasPluginGlobal: typeof window.Capacitor
  }));
  console.log('=== VERSION LIVRÉE (app.js final) ===');
  console.log('  chargement terminé :', !state.loadingVisible ? 'oui' : 'non');
  console.log('  écran affiché      :', state.setupVisible ? 'première installation' : state.loginVisible ? 'connexion' : 'application');
  console.log('  état persisté      :', state.stored.toLocaleString('fr'), 'caractères');
  console.log('  #print-root        : positionné à', state.printRootOffscreen, '(hors écran)');
  console.log('  Capacitor présent  :', state.hasPluginGlobal, '(normal : absent dans un navigateur)');
  console.log('  erreurs JS         :', errors.length === 0 ? 'aucune' : errors.join(' | '));
  await b.close();
})();

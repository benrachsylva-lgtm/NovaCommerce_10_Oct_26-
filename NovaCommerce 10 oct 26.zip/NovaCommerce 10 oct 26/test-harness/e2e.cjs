/* Test de bout en bout dans Chromium réel : parcours commande express,
   pannes d'écriture simulées, exports et impression côté Android. */
const puppeteer = require('puppeteer');

const step = (name, ok, detail = '') => console.log(`${ok ? '  ✓' : '  ✗'} ${name}${detail ? ' — ' + detail : ''}`);

(async () => {
  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e.message)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  // Indispensable : window.confirm bloque la page tant qu'aucune réponse n'est donnée.
  page.on('dialog', async (dialog) => { await dialog.accept(); });
  await page.goto('http://127.0.0.1:4173/__qa-index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('!!window.__novaDebug', { timeout: 30000 });
  await new Promise((r) => setTimeout(r, 1200));

  console.log('=== A. DÉMARRAGE ET ÉTAT INITIAL ===');
  const boot = await page.evaluate(() => {
    const stored = window.localStorage.getItem('nova-commerce-state-v1') || '';
    return { chars: stored.length, hasDebug: !!window.__novaDebug };
  });
  step('Application chargée, état seedé et écrit dans localStorage', boot.chars > 0, boot.chars.toLocaleString('fr') + ' caractères');
  const size = await page.evaluate(() => window.__novaDebug.saveSize());
  const quota = await page.evaluate(() => {
    const used = (localStorage.getItem('nova-commerce-state-v1') || '').length;
    let lo = 0, hi = 20000000;
    while (lo < hi) { const mid = Math.floor((lo + hi + 1) / 2); try { localStorage.setItem('__q', 'a'.repeat(mid)); lo = mid; } catch (e) { hi = mid - 1; } }
    localStorage.removeItem('__q');
    return used + lo; // état existant + espace encore disponible = quota total
  });
  step('Occupation du quota localStorage', size / quota < 0.6, `${(size / quota * 100).toFixed(1)} % (${size.toLocaleString('fr')} / ${quota.toLocaleString('fr')})`);

  console.log('\n=== B. MODULE COMMANDES → COMMANDE EXPRESS ===');
  const express = await page.evaluate(() => {
    const d = window.__novaDebug;
    const admin = d.state.users.find((u) => u.profile === 'Administrateur');
    d.user = admin;
    d.render();
    const lines = d.compute();
    d.draft = { analysisDays: 30, coverageDays: 21, storeId: '', generatedAt: new Date().toISOString(), lines };
    return { user: admin.name, proposals: lines.length, withSupplier: lines.filter((l) => l.supplierId).length, before: d.state.orders.length };
  });
  step('Analyse express', express.proposals > 0, `${express.proposals} proposition(s), ${express.withSupplier} avec fournisseur`);
  const generated = await page.evaluate(() => {
    const d = window.__novaDebug;
    const before = d.state.orders.length;
    d.generate();
    return { created: d.state.orders.length - before, express: d.state.orders.filter((o) => o.express).length, saved: window.localStorage.getItem('nova-commerce-state-v1').includes('"express":true') };
  });
  step('Génération des bons de commande (Brouillon)', generated.created > 0, `${generated.created} bon(s) créé(s), ${generated.express} express au total`);
  step('Écriture effectivement persistée', generated.saved === true, 'les bons figurent dans le stockage');
  const noGenericToast = await page.evaluate(() => !document.body.innerText.includes('ne permet pas cette écriture'));
  step('Aucun message d’erreur générique', noGenericToast);

  console.log('\n=== C. PANNE SIMULÉE : SESSION EXPIRÉE (Desktop) ===');
  const sessionCase = await page.evaluate(async () => {
    const d = window.__novaDebug;
    // Contexte Desktop : le pont Electron est présent (c'est le seul endroit d'où
    // provient une erreur de session).
    window.novaDesktop = { isElectron: true, authenticate: async () => ({ ok: true, user: { id: 'user-admin', name: 'Administrateur' } }) };
    const original = window.localStorage.setItem.bind(window.localStorage);
    const failure = Object.assign(new Error('Session expirée : reconnectez-vous pour enregistrer.'), { code: 'NOVA_SESSION_EXPIRED' });
    Object.defineProperty(window.localStorage, 'setItem', { configurable: true, value: () => { throw failure; } });
    const saved = d.save();
    const modalOpened = !!document.querySelector('#session-recovery-form');
    const modalText = document.querySelector('#modal-root')?.innerText || '';
    Object.defineProperty(window.localStorage, 'setItem', { configurable: true, value: original });
    return { saved, modalOpened, modalText: modalText.slice(0, 160), hasPasswordField: !!document.querySelector('#session-recovery-form input[type="password"]') };
  });
  step('saveState() signale l’échec', sessionCase.saved === false);
  step('Fenêtre de reconnexion proposée (Desktop)', sessionCase.modalOpened === true && sessionCase.hasPasswordField === true, sessionCase.modalText.replace(/\n+/g, ' ').slice(0, 90));
  step('Le message générique a disparu (session)', !/ne permet pas cette écriture/.test(sessionCase.modalText));
  const replayCase = await page.evaluate(async () => {
    const d = window.__novaDebug;
    const form = document.querySelector('#session-recovery-form');
    form.querySelector('input[name="password"]').value = 'motdepasse-test';
    form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
    await new Promise((r) => setTimeout(r, 120));
    return { modalClosed: !document.querySelector('#session-recovery-form'), size: d.saveSize(), persisted: (localStorage.getItem('nova-commerce-state-v1') || '').length > 0 };
  });
  step('Saisie rejouée après reconnexion (sans perte)', replayCase.modalClosed === true && replayCase.persisted === true);

  console.log('\n=== D. PANNE SIMULÉE : QUOTA SATURÉ (APK / PWA) ===');
  const quotaCase = await page.evaluate(() => {
    const d = window.__novaDebug;
    document.querySelector('#modal-root').innerHTML = '';
    document.querySelector('#toast-stack').innerHTML = '';
    const original = window.localStorage.setItem.bind(window.localStorage);
    const failure = Object.assign(new Error("Failed to execute 'setItem' on 'Storage': Setting the value of 'nova-commerce-state-v1' exceeded the quota."), { name: 'QuotaExceededError' });
    Object.defineProperty(window.localStorage, 'setItem', { configurable: true, value: () => { throw failure; } });
    const saved = d.save();
    const toasts = document.querySelector('#toast-stack')?.innerText || '';
    Object.defineProperty(window.localStorage, 'setItem', { configurable: true, value: original });
    delete window.novaDesktop;
    return { saved, toasts: toasts.replace(/\n+/g, ' ') };
  });
  step('Message spécifique au quota', /satur|plein|sauvegarde/i.test(quotaCase.toasts), quotaCase.toasts.slice(0, 120));
  step('Le message générique a disparu', !/ne permet pas cette écriture/.test(quotaCase.toasts));

  console.log('\n=== E. EXPORT (Android simulé) : plugin natif appelé ===');
  const exportCase = await page.evaluate(async () => {
    const calls = [];
    window.Capacitor = { isNativePlatform: () => true, Plugins: { NovaExport: {
      saveToDevice: (o) => { calls.push(o); return Promise.resolve({ fileName: o.fileName, path: 'Téléchargements/NOVA Commerce/' + o.fileName, uri: 'content://media/1' }); },
      shareFile: () => Promise.resolve({}), printPage: () => Promise.resolve({ completed: true })
    } } };
    const d = window.__novaDebug;
    d.exports.saveTextFile('test-ventes.csv', '\ufeffLibellé;Montant\nRiz 5kg;5 200', 'text/csv;charset=utf-8');
    await new Promise((r) => setTimeout(r, 80));
    window.printCalls = 0;
    const realPrint = window.print; window.print = () => { window.printCalls += 1; };
    const cleanup = { done: false };
    d.exports.printCurrentPage(() => { cleanup.done = true; });
    await new Promise((r) => setTimeout(r, 80));
    window.print = realPrint;
    const decoded = calls[0] ? decodeURIComponent(escape(atob(calls[0].base64))) : '';
    return { call: calls[0], printCalls: window.printCalls, cleanupDone: cleanup.done, decoded };
  });
  step('Enregistrement délégué au plugin natif', !!exportCase.call, exportCase.call ? exportCase.call.fileName + ' · ' + exportCase.call.mimeType : 'aucun appel');
  step('Contenu CSV UTF-8 transmis intact', exportCase.decoded.includes('Libellé;Montant') && exportCase.decoded.includes('Riz 5kg'), JSON.stringify(exportCase.decoded.slice(0, 42)));
  step('Impression native privilégiée (pas de window.print)', exportCase.printCalls === 0 && exportCase.cleanupDone === true);

  console.log('\n=== F. IMPRESSION : document hors écran ===');
  const printCase = await page.evaluate(async () => {
    let atPrintTime = 0;
    let styles = null;
    window.Capacitor = { isNativePlatform: () => true, Plugins: { NovaExport: {
      saveToDevice: () => Promise.resolve({}),
      shareFile: () => Promise.resolve({}),
      printPage: () => { atPrintTime = document.getElementById('print-root').innerHTML.length; const c = getComputedStyle(document.getElementById('print-root')); styles = { position: c.position, left: c.left }; return Promise.resolve({ completed: true }); }
    } } };
    window.__novaDebug.exports.printFullReport('ventes');
    await new Promise((r) => setTimeout(r, 60));
    return { atPrintTime, styles, afterCleanup: document.getElementById('print-root').innerHTML.length };
  });
  step('Rapport PDF composé pour l’impression', printCase.atPrintTime > 500, printCase.atPrintTime.toLocaleString('fr') + ' caractères au moment de l’impression');
  step('Document hors écran pendant l’impression', printCase.styles?.position === 'absolute' && parseFloat(printCase.styles.left) < -1000, printCase.styles ? `position=${printCase.styles.position}, left=${printCase.styles.left}` : '');
  step('Document retiré après l’envoi', printCase.afterCleanup === 0);

  console.log('\n=== H. COMMANDE EXPRESS : panne de session pendant la génération ===');
  const sessionExpress = await page.evaluate(async () => {
    const d = window.__novaDebug;
    document.querySelector('#modal-root').innerHTML = '';
    window.novaDesktop = { isElectron: true, authenticate: async () => ({ ok: true, user: { id: 'user-admin', name: 'Administrateur' } }) };
    document.querySelector('#session-recovery-form')?.remove();
    const original = window.localStorage.setItem.bind(window.localStorage);
    Object.defineProperty(window.localStorage, 'setItem', { configurable: true, value: () => { throw Object.assign(new Error('Session expirée'), { code: 'NOVA_SESSION_EXPIRED' }); } });
    const lines = d.compute();
    d.draft = { analysisDays: 30, coverageDays: 21, storeId: '', generatedAt: new Date().toISOString(), lines };
    const before = d.state.orders.length;
    d.generate();
    const afterFailure = d.state.orders.length;
    window.__beforeH = before;
    const draftKept = !!d.state.orders.filter((o) => o.express).length;
    // Reconnexion : l'écriture doit être rejouée automatiquement
    Object.defineProperty(window.localStorage, 'setItem', { configurable: true, value: original });
    const form = document.querySelector('#session-recovery-form');
    form.querySelector('input[name="password"]').value = 'motdepasse-test';
    form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
    await new Promise((r) => setTimeout(r, 150));
    return {
      created: afterFailure - before,
      afterReplay: d.state.orders.length,
      addedAfterReplay: d.state.orders.length - afterFailure,
      draftKept,
      persisted: (localStorage.getItem('nova-commerce-state-v1') || '').includes('"express":true'),
      successModal: (document.querySelector('#modal-root')?.innerText || '').includes('bon(s) de commande créé(s)'),
      genericMessage: (document.body.innerText || '').includes('ne permet pas cette écriture')
    };
  });
  step('Bons générés malgré la panne', sessionExpress.created > 0, sessionExpress.created + ' bon(s) préparé(s)');
  step('Reconnexion : écriture rejouée, aucun doublon', sessionExpress.persisted === true && sessionExpress.addedAfterReplay === 0, sessionExpress.afterReplay + ' commande(s) au total, ' + sessionExpress.addedAfterReplay + ' ajoutée(s) par la reconnexion');
  step('Écran de confirmation restitué', sessionExpress.successModal === true);
  step('Aucun message générique', sessionExpress.genericMessage === false);
  const noDup = await page.evaluate(() => {
    const d = window.__novaDebug;
    const numbers = d.state.orders.filter((o) => o.express).map((o) => o.number);
    return { total: numbers.length, unique: new Set(numbers).size };
  });
  step('Numéros de bons uniques (pas de doublon)', noDup.total === noDup.unique, noDup.total + ' bons express · ' + noDup.unique + ' numéros distincts');

  console.log('\n=== G. RÉGRESSION : parcours classique toujours fonctionnel ===');
  const classic = await page.evaluate(() => {
    const d = window.__novaDebug;
    delete window.Capacitor;
    const before = d.state.orders.length;
    const order = { id: 'order-test', number: 'CMD-TEST-001', date: '2026-09-26', type: 'Prévisionnelle', supplierId: 'sup-01', storeId: 'store-main', lines: [{ productId: 'prod-01', quantity: 5, unitPrice: 1000 }], total: 5000, status: 'Brouillon' };
    d.state.orders.unshift(order);
    const saved = d.save();
    return { saved, count: d.state.orders.length - before, persisted: window.localStorage.getItem('nova-commerce-state-v1').includes('CMD-TEST-001') };
  });
  step('Commande manuelle enregistrée (navigateur)', classic.saved === true && classic.persisted === true);

  console.log('\n=== ERREURS JAVASCRIPT ===');
  const realErrors = errors.filter((e) => !/favicon|manifest|service.?worker|Failed to load resource/i.test(e)
    && !/NOVA: échec de persistance/i.test(e)); // les deux pannes de cet essai sont simulées volontairement
  step('Aucune erreur JavaScript', realErrors.length === 0, realErrors.slice(0, 3).join(' | '));
  await browser.close();
  console.log('\n' + (realErrors.length === 0 ? 'E2E : OK' : 'E2E : ERREURS DÉTECTÉES'));
})().catch((e) => { console.error('ÉCHEC E2E:', e.message); process.exit(1); });
